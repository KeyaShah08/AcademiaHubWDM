INSERT INTO courses (name, description, instructor_id)
VALUES
  ('CSE 5355: Web Data Management', 'This course provides an in-depth study of web data management, focusing on the principles, technologies, and best practices for handling data in web-based applications. Students will learn about data modeling, storage, retrieval, and manipulation techniques in the context of web development.', 1000002),
  ('CSE 5330: Database System', ' Database system architecture; management and analysis of files, indexing, hashing, and B+-trees; the relational model and algebra; the SQL database language; database programming techniques, database design using Entry-Relationship, extended E-R, and UML modeling; basics of normalization. Introduction to database security, query processing and transaction management.', 1000002),
  ('CSE 5344: Computer Networks', 'Study of computer network architectures, protocols, and interfaces. The OSI reference model and the Internet architecture will be discussed. Networking techniques such as multiple access, packet/cell switching, and internetworking will be studied. Discussion will also include end-to-end protocols, congestion control, high-speed networking, and network management.', 1000002);
  ('CSE 5302: Data Mining', 'This course explores the principles and techniques of data mining, with a focus on extracting valuable information and patterns from large datasets. Topics include data preprocessing, association rule mining, clustering, classification, and decision trees. Students will also gain practical experience with data mining tools and applications.', 1000002),
  ('CSE 5360: Cloud Computing', 'An in-depth study of cloud computing technologies and their applications. Topics include cloud service models (IaaS, PaaS, SaaS), virtualization, cloud architecture, scalability, and security in cloud environments. Students will also learn how to deploy and manage applications on popular cloud platforms.', 1000002),
  ('CSE 5375: Advanced Computer Networks', 'An advanced course in computer networks, focusing on emerging technologies and protocols. Topics include network virtualization, software-defined networking (SDN), network security, and advanced routing and switching techniques. Students will gain hands-on experience in configuring and managing complex network environments.', 1000002);
  ('CSE 5320: Secure Programming', 'This course focuses on secure programming practices and techniques to develop software applications with a strong emphasis on security. Topics include secure coding standards, common vulnerabilities, secure design principles, and the use of security tools and libraries. Students will learn to write code that is resistant to common security threats.', 1000002),
  ('CSE 5390: Distributed Systems', 'An in-depth exploration of distributed systems and their design principles. Topics include distributed architectures, distributed algorithms, distributed data storage, and communication protocols. Students will gain insights into building and managing scalable and fault-tolerant distributed systems.', 1000002),
  ('CSE 5380: Software Programs', 'This course covers various aspects of software programs, including software development methodologies, project management, and software testing. Students will learn to design, develop, and manage software programs effectively, addressing real-world challenges in the software development process.', 1000002);



INSERT INTO contact (email, message, name, resolved) VALUES
    ('john@example.com', 'Hello, I have a question.', 'John Doe', 0),
    ('alice@example.com', 'Please help with my inquiry.', 'Alice Smith', 0),
    ('bob@example.com', 'This is a sample message.', 'Bob Johnson', 1);

INSERT INTO policies (title, description) VALUES
('Admissions Policies', 'Our Admissions Policies outline the criteria and procedures for admitting students into our institution. Learn about our admission requirements, application process, and more.'),
('Integrity Policies', 'Integrity is a core value at our institution. Our Integrity Policies define academic and ethical standards expected from all students. Discover our commitment to honesty and integrity.'),
('Grading and Evaluation Policies', 'Grading and Evaluation Policies provide insight into how your academic performance is assessed. Learn about our grading system, evaluation methods, and how we ensure fair assessment.'),
('Student Rights and Responsibilities', 'Understanding your rights and responsibilities as a student is important. Our policies detail what you can expect from us and what we expect from you during your academic journey.');
