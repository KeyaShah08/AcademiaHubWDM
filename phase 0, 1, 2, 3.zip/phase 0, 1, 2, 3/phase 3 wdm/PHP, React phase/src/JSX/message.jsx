import React, { useState } from "react";
import messageCSS from "../CSS/qa_message.module.css"; 
import axios from "axios";
import Url from "../BackendURL";
import { Session } from "../UserContext";

const Message = () => {

  const { userObject } = Session();

  const [formData, setFormData] = useState({
    email: "",
    role:"instructor",
    message:"",
    from: userObject?.user_id
  });

  const handleSignup = async (e) => {
    e.preventDefault();
    const formDetails = new FormData();
    formDetails.append('email', formData.email);
    formDetails.append('message', formData.message);
    formDetails.append('from', formData.from);
    formDetails.append('role', formData.role);
    await axios.post(`${Url}api/message.php`, formDetails, {
      headers: {
        'Content-Type': 'multipart/form-data', // Set the content type to multipart form data
      },
    })
    .then(async (res) => {
      if (res.data === 'User Not Found'){
        alert('User Not Found');
      }else{
        setFormData({ ...formData, email: "",role:"", message:"", });
        alert('Message Sent');
        console.log(res.data);
      }


    })
    .catch((error) => {
      // Handle any errors that occur during the Axios request
      console.error('Error:', error);
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };


  return (
    <div className={`${messageCSS["message-body"]}`}>
      <div className={messageCSS["message-container"]}>
        <h2>Message</h2>
        <form onSubmit={handleSignup}>
          <p>Send Message to:</p>
          <input type="radio" id="Peer" name="role" value="student" onChange={handleInputChange}/>
          <label htmlFor="peer">Student</label>
          <br />
          <input
            type="radio"
            id="instructor"
            name="role"
            value={formData.role}
            onChange={handleInputChange}
          />
          <label htmlFor="instructor">Instructor</label>
          <br />
          <input type="radio" id="qa" name="role" value="qa" onChange={handleInputChange} required/>
          <label htmlFor="qa">Program Coordinator</label>
          <br />
          <input type="radio" id="admin" name="role" value="admin" onChange={handleInputChange} required />
          <label htmlFor="admin">Admin</label>
          <br />
          <p>Email:</p>
          <input
            id="email"
            name="email"
           type="email"
           value={formData.email}
            onChange={handleInputChange}
            required
          ></input>
          <p>Message:</p>
          <textarea
            id="feedback"
            name="message"
            rows="4"
            cols="20"
            value={formData.message}
            onChange={handleInputChange}
            required
          ></textarea>
          <input type="submit" value="Send" />
        </form>
      </div>
    </div>
  );
};

export default Message;
