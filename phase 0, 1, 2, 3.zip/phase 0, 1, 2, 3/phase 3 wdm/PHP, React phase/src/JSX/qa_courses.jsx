import React, {useState, useEffect} from "react";
import courseCSS from "../CSS/qa_courses.module.css";
import { Link } from "react-router-dom";
import axios from "axios";
import Url from "../BackendURL";
import { Session } from "../UserContext";

function QA_COURSES() {
  const {userObject} = Session();
  const [data, setData] = useState([]);
  useEffect(()=>{
    axios
    .get(`${Url}api/getallcourses.php`)
    .then((response) => {
      setData(response.data);
    })
    .catch((error) => {
      console.error("Error fetching data:", error);
    });
  },[]);
  return (
    <div className={courseCSS["course-body"]}>

      <div className={courseCSS["qa-container"]}>
        <h1>Courses and Instructors</h1>
        <table className={courseCSS["qa-table"]}>
          <thead>
            <tr>
              <th className={courseCSS["qa-th"]}>Course</th>
              <th className={courseCSS["qa-th"]}>Instructor</th>
              <th className={courseCSS["qa-th"]}>Action</th>
            </tr>
          </thead>
          <tbody>
          {data.map((course, index) => (
                <tr key={index}>
                <td className={courseCSS["qa-td"]}>
                  {course.courseName}
                </td>
                <td className={courseCSS["qa-td"]}>{course.name}</td>
                <td className={courseCSS["qa-td"]}>
                  {userObject?.role === 'qa' ? 
                  <Link to={`/qa_report/${course.courseId}`}><button className={courseCSS["report-button"]}>Report</button>
                  </Link> :
                  <Link to={`/pc_report/${course.courseId}`}><button className={courseCSS["report-button"]}>Report</button>
                  </Link>
                  }
                    
                </td>
              </tr>
              ))}
            
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default QA_COURSES;
