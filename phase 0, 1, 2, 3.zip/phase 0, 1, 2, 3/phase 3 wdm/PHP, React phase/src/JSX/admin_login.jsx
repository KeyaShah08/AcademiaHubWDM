import React, { useState } from "react";
import loginCSS from "../CSS/admin_login.module.css";
import university from "../FILES/university.jpg";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import Url from "../BackendURL";
import { Session } from "../UserContext";

const UniversityLogin = () => {
	const navigate = useNavigate();
	const { login } = Session();

	const [formData, setFormData] = useState({
		email: "",
		password: "",
	});

	const handleSignup = async (e) => {
		e.preventDefault();
		const formDetails = new FormData();
		formDetails.append("email", formData.email);
		formDetails.append("password", formData.password);
		await axios
			.post(`${Url}api/login.php`, formDetails, {
				headers: {
					"Content-Type": "multipart/form-data", // Set the content type to multipart form data
				},
			})
			.then(async (res) => {
				if (res.data === "Wrong password") {
					alert("Wrong password");
				} else if (res.data === "Invalid Email") {
					alert("Invalid email");
				} else {
					await login(res.data);
					if(res.data.role === 'student'){
						navigate("/student_dashboard");
					}
					else if(res.data.role === 'admin'){
						navigate("/admin_admin");
					}
					else if (res.data.role === 'instructor'){
						navigate("/instructor_dashboard");
					}
					else if(res.data.role === 'pc'){
						navigate("/pg_dashboard");
					}
					else{
						navigate("/qa_dashboard");
					}
					
				}
			})
			.catch((error) => {
				// Handle any errors that occur during the Axios request
				console.error("Error:", error);
			});
	};

	const handleInputChange = (e) => {
		const { name, value } = e.target;
		setFormData({
			...formData,
			[name]: value,
		});
	};
	return (
		<div className={`${loginCSS["login-body"]}`}>
			<img src={university} alt="University" className={loginCSS["background-image"]} />
			<div className={`${loginCSS["login-container"]}`}>
				<Link to="/" className={loginCSS["homepage-button"]}>
					<br />
					<button>Homepage</button>
				</Link>
				<br />
				<h1 className={`${loginCSS["login-h1"]}`}>University Login</h1>
				<form className={`${loginCSS["login-form"]}`} onSubmit={handleSignup}>
					<input className={`${loginCSS["login-inputField"]}`} type="email" name="email" placeholder="Email" onChange={handleInputChange} required />
					<input className={`${loginCSS["login-inputField"]}`} type="password" name="password" placeholder="Password" onChange={handleInputChange} required />
					<button type="submit" className={loginCSS["login-button"]}>
						Login
					</button>
				</form>
				
				<Link to="/forgetpassword" className={loginCSS["login-a"]}>
					Forget Password?
				</Link>
				<br />
				<p>
					Don't have an account?
					<Link to="/signup" className={loginCSS["login-a"]}>
						Sign up
					</Link>
				</p>
			</div>
		</div>
	);
};

export default UniversityLogin;
