import React, {useState, useEffect} from "react";
import courseCSS from "../CSS/student_coursematerial.module.css";
import { Link } from 'react-router-dom'; // Make sure to adjust the import path if necessary
import {  useParams } from 'react-router-dom'; 
import axios from "axios";
import Url from "../BackendURL";


const StudentCourseMaterial = () => {
  const {courseId} = useParams();

  const [data, setData] = useState([]);


  useEffect(() => {
    function getCourseDescription(){
      const formDetails = new FormData();
      formDetails.append('courseId', courseId);
      axios.post(`${Url}api/getCourseInfo.php`,formDetails,{
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      })
        .then((response) => {
          setData(response.data);
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    }
    // Make the HTTP request to the PHP file
    getCourseDescription();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  return (
    <div className={courseCSS["coursem-body"]}>
      
      <div className={courseCSS["course-container"]}>
        <h1 className={courseCSS["course-h1"]}>{data.name}</h1>
        <p>{data.description}</p>

        <h2>Modules</h2>
        <div className={courseCSS["course-module"]}>
          <Link to="../FILES/3rdEd_Chapter 1.pptx" download>
            Module 1: Introduction to Web Development
          </Link>
        </div>
        <div className={courseCSS["course-module"]}>
          <Link to="../FILES/3rdEd_Chapter 2.pptx" download>
            Module 2: How the Web Works
          </Link>
        </div>
        <div className={courseCSS["course-module"]}>
          <Link to="../FILES/3rdEd_Chapter 3.pptx" download>
            Module 3: HTML Introduction
          </Link>
        </div>
        <div className={courseCSS["course-module"]}>
          <Link to="../FILES/3rdEd_Chapter 5.pptx" download>
            Module 4: HTML 2: Tables and Forms
          </Link>
        </div>
        <div className={courseCSS["course-module"]}>
          <Link to="../FILES/module1.pdf" download>
            Module 5: CSS Layout
          </Link>
        </div>
        <div className={courseCSS["course-module"]}>
          <Link to="../FILES/module2.pdf" download>
            Module 6: Javascript Fundamentals
          </Link>
        </div>
        <div className={courseCSS["course-module"]}>
          <Link to="../FILES/module1.pdf" download>
            Module 7: Using JvaScript
          </Link>
        </div>
        <div className={courseCSS["course-module"]}>
          <Link to="../FILES/module2.pdf" download>
            Module 8: React
          </Link>
        </div>
        <div className={courseCSS["course-module"]}>
          <Link to="../FILES/module1.pdf" download>
            Module 9: Server Side Development: PHP
          </Link>
        </div>
        <div className={courseCSS["course-module"]}>
          <Link to="../FILES/module2.pdf" download>
            Module 10: Server-Side Node.js
          </Link>
        </div>

        <p>
          For more information, contact:{" "}
          <Link to="mailto:instructor@email.com">Stella Breeze</Link>
        </p>
      </div>
    </div>
  );
};

export default StudentCourseMaterial;
