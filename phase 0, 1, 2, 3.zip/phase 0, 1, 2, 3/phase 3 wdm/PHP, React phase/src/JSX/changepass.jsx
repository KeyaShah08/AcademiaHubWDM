import React, { useState } from "react";
import pwdCSS from "../CSS/admin_forgetpassword.module.css";
import { Link } from "react-router-dom";
import axios from "axios";
import Url from "../BackendURL";
import { useParams } from "react-router-dom";


const ChangePass = () => {
    const { id } = useParams();
	const [pass, setPass] = useState(""); // State for the email input

	const handlePassChange = (e) => {
		setPass(e.target.value);
	};

	const handleSubmit = (e) => {
		e.preventDefault();
		// Send the email for password reset here
		const formDetails = new FormData();
		formDetails.append("id", id);
        formDetails.append("pass", pass);
		 axios
			.post(`${Url}api/forgotchange.php`, formDetails, {
				headers: {
					"Content-Type": "multipart/form-data", // Set the content type to multipart form data
				},
			})
			.then( (res) => {
				if (res.data === "Password update failed") {
					alert("Password update failed");
				}  else {
          alert("Password Changed Successfully");
				}
			})
			.catch((error) => {
				// Handle any errors that occur during the Axios request
				console.error("Error:", error);
			});
	};

	return (
		<div className={pwdCSS["pwd-body"]}>
			<div className={pwdCSS["pwd-container"]}>
				<h1 className={pwdCSS["pwd-h1"]}>Change Password </h1>
				<form className={pwdCSS["pwd-form"]} action="/forgot-password" method="post" onSubmit={handleSubmit}>
					<label className={pwdCSS["pwd-label"]} htmlFor="email">
						New Password:
					</label>
					<input className={pwdCSS["pwd-inputField"]} type="password" id="pass" name="pass" required value={pass} onChange={handlePassChange} />
					<button className={pwdCSS["pwd-button"]} type="submit">
						Submit
					</button>
				</form>
				<p className={pwdCSS["pwd-p"]}>
					Back to login Page?{" "}
					<Link to="/login" className={pwdCSS["pwd-a"]}>
						Log in
					</Link>
				</p>
			</div>
		</div>
	);
};

export default ChangePass;
