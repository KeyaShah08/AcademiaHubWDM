import React, { useState, useEffect } from "react";
import infoCSS from "../CSS/admin_studentsinfo.module.css";
import { Link } from "react-router-dom"; // Make sure to adjust the import path if necessary
import { useParams } from "react-router-dom";
import axios from "axios";
import Url from "../BackendURL";
const StudentInfo = () => {
	const { role } = useParams();
	const [data, setData] = useState([]);
	useEffect(() => {
		function getData() {
			const formDetails = new FormData();
			formDetails.append("role", role);
			axios
				.post(`${Url}api/getusers.php`, formDetails, {
					headers: {
						"Content-Type": "multipart/form-data",
					},
				})
				.then((response) => {
					setData(response.data);
				})
				.catch((error) => {
					console.error("Error fetching data:", error);
				});
		}
		// Make the HTTP request to the PHP file
		getData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	return (
		<div className={infoCSS["info-body"]}>
			<br />
			<br />

			<main>
				<section>
					<h2 className={infoCSS["info-h2"]}>
						{role === "student" && "Student"}
						{role === "instructor" && "Instructor"}
						{role === "pc" && "Program Coordinators"}
						{role === "qa" && "QA Officers"} Details
					</h2>
					<table className={infoCSS["studentinfotable"]}>
						<thead>
							<tr>
								<th className={infoCSS["studentinfotable-th"]}>User ID</th>
								<th className={infoCSS["studentinfotable-th"]}>Name</th>
								<th className={infoCSS["studentinfotable-th"]}>Email</th>
							</tr>
						</thead>
						<tbody>
							{data.map((user, index) => (
								<tr key={index}>
									<td className={infoCSS["studentinfotable-td"]}><Link to={`/admin_userprofile/${role}/${user.email}/${user.name}`}>{user.id}</Link></td>
									<td className={infoCSS["studentinfotable-td"]}>{user.name}</td>
									<td className={infoCSS["studentinfotable-td"]}>{user.email}</td>
								</tr>
							))}
						
						</tbody>
					</table>
				</section>
			</main>
		</div>
	);
};

export default StudentInfo;
