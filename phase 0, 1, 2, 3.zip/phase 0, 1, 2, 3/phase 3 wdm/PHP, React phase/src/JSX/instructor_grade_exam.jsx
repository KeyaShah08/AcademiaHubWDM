import React, {useEffect, useState} from "react";
import gradeCSS from "../CSS/instructor_grade_exam.module.css";
import { Link } from 'react-router-dom'; // Make sure to adjust the import path if necessary
import { useParams } from "react-router-dom";
import axios from "axios";
import Url from "../BackendURL";

const InstructorGradeExam = () => {
  const { courseId } = useParams();
  const [data, setData] = useState([]);

  useEffect(() => {
		function getData() {
			const formDetails = new FormData();
			formDetails.append("course_id", courseId);
			axios
				.post(`${Url}api/fetchexaminstructor.php`, formDetails, {
					headers: {
						"Content-Type": "multipart/form-data",
					},
				})
				.then((response) => {
					setData(response.data);
				})
				.catch((error) => {
					console.error("Error fetching data:", error);
				});
		}
		// Make the HTTP request to the PHP file
		getData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

  return (
    <div className={gradeCSS["grade-body"]}>

      <h1 className={gradeCSS["grade-h1"]}>Grade Exam</h1>
      <table className={gradeCSS["grade-table"]}>
        <thead>
          <tr>
            <th className={gradeCSS["grade-th"]}>Exam Title</th>
            <th className={gradeCSS["grade-th"]}>Due Date</th>
            <th className={gradeCSS["grade-th"]}>Action</th>
          </tr>
        </thead>
        <tbody>
          {data.map((exam, index) => (
								<tr key={index}>
                <td className={gradeCSS["grade-td"]}>{exam.title}</td>
                <td className={gradeCSS["grade-td"]}>{exam.date}</td>
                <td className={gradeCSS["grade-td"]}>
                  <Link to={`/instructor_examresult/${exam.exam_id}`}><button className={gradeCSS["grade-button"]}>View Results</button></Link>
                </td>
              </tr>
							))}

          
        </tbody>
      </table>
    </div>
  );
};

export default InstructorGradeExam;
