import React, { useState, useEffect } from "react";
import adminCSS from "../CSS/admin_admin.module.css";
import { Link } from "react-router-dom"; // Make sure to adjust the import path if necessary
import axios from "axios";
import Url from "../BackendURL";

const AdminPage = () => {
	const [courses, setCourses] = useState([]);
	const [accessData, setAccessData] = useState([]);
	const [formData, setFormData] = useState({
		email: "",
		course: "",
	});
	const handleInputChange = (e) => {
		const { name, value } = e.target;
		setFormData({
			...formData,
			[name]: value,
		});
	};

	function getCourses() {
		axios
			.get(`${Url}api/getallcourses.php`)
			.then((response) => {
				setCourses(response.data);
				if (response.data.length > 0) {
					// Set the course value to the courseId of the first row
					setFormData({
						...formData,
						course: response.data[0].courseId,
					});
				}
			})
			.catch((error) => {
				console.error("Error fetching data:", error);
			});
		axios
			.get(`${Url}api/adminaccesstable.php`)
			.then((response) => {
				setAccessData(response.data);
			})
			.catch((error) => {
				console.error("Error fetching data:", error);
			});
	}

	useEffect(() => {
		// Make the HTTP request to the PHP file
		getCourses();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const handleAccess = () => {
		if(formData.email.length === 0){
			alert("Missing Data");
			return;
		}
		const formDetails = new FormData();
		formDetails.append("course_id", formData.course);
		formDetails.append("email", formData.email);
		axios
			.post(`${Url}api/addaccess.php`, formDetails, {
				headers: {
					"Content-Type": "multipart/form-data", // Set the content type to multipart form data
				},
			})
			.then((response) => {
				if (response.data) {
					getCourses();
					alert(response.data);
				}
			})
			.catch((error) => {
				console.error("Error fetching data:", error);
			});
	};

	const removeAccess = (eid) => {
		axios
			.delete(`${Url}api/removeaccess.php?eid=${eid}`)
			.then((response) => {
				if (response.data) {
					getCourses();
					alert(response.data);
				}
			})
			.catch((error) => {
				console.error("Error fetching data:", error);
			});
	};
	return (
		<div className={adminCSS["admin-body"]}>
			<div className={adminCSS["admin-tile"]}>
				<h2 className={adminCSS["admin-h2"]}>Students</h2>
				<div>
					<button>
						<Link to="/admin_profiles/student">View Details</Link>
					</button>
				</div>
			</div>
			<div className={adminCSS["admin-tile"]}>
				<h2 className={adminCSS["admin-h2"]}>Instructors</h2>
				<div>
					<button>
						<Link to="/admin_profiles/instructor">View Details</Link>
					</button>
				</div>
			</div>
			<div className={adminCSS["admin-tile"]}>
				<h2 className={adminCSS["admin-h2"]}>Coordinators</h2>
				<div>
					<button>
						<Link to="/admin_profiles/pc">View Details</Link>
					</button>
				</div>
			</div>
			<div className={adminCSS["admin-tile"]}>
				<h2 className={adminCSS["admin-h2"]}>QA-Officers</h2>
				<div>
					<button>
						<Link to="/admin_profiles/qa">View Details</Link>
					</button>
				</div>
			</div>

			<h1 className={adminCSS["admin-h1"]}>Add Student's Access</h1>
			<table className={adminCSS["user-access-table"]}>
				<tbody>
					<tr>
						<th className={adminCSS["user-access-table-th"]}>Email:</th>
						<td className={adminCSS["user-access-table-td"]}>
							<input type="email" id="email" name="email" required value={formData.email} onChange={handleInputChange} />
						</td>
					</tr>
					<tr>
						<th className={adminCSS["user-access-table-th"]}>Course:</th>
						<td className={adminCSS["user-access-table-td"]}>
							<select id="course" name="course" value={formData.course} onChange={handleInputChange}>
								{courses.map((course, index) => (
									<option key={index} value={course.courseId}>
										{course.courseName}
									</option>
								))}
							</select>
						</td>
					</tr>
					<tr>
						<td className={adminCSS["user-access-table-td"]} colSpan="2">
							<button onClick={handleAccess}>Give Access</button>
						</td>
					</tr>
				</tbody>
			</table>

			<div>
				<h1>User Table</h1>
				<table style={{ width: "100%", textAlign: "left" }}>
					<thead>
						<tr>
							<th style={{ border: "1px solid #000" }}>Email</th>
							<th style={{ border: "1px solid #000" }}>Course Name</th>
							<th style={{ border: "1px solid #000" }}>Actions</th>
						</tr>
					</thead>
					<tbody>
						{accessData.map((access) => (
							<tr key={access.eid}>
								<td>{access.email}</td>
								<td>{access.courseName}</td>
								<td style={{ textAlign: "center" }}>
									<button
										onClick={() => removeAccess(access.eid)}
										className="remove-button"
										style={{ backgroundColor: "red", color: "white", border: "none", padding: "5px 10px", cursor: "pointer" }}>
										Remove
									</button>
								</td>
							</tr>
						))}
					</tbody>
				</table>
			</div>

			<Link to="/admin_monitor" className={adminCSS["button1"]}>
				Monitor Activities
			</Link>
			<br />

			<div className={adminCSS["chat-container"]}>
				<div className={adminCSS["chat-header"]}>Help Desk Chat Bot</div>
				<div className={adminCSS["chat-messages"]}>Hi, How may I help you?</div>
				<div className={adminCSS["chat-input"]}>
					<input type="text" />
					<button className={adminCSS["send-button"]}>Send</button>
				</div>
			</div>
		</div>
	);
};

export default AdminPage;
