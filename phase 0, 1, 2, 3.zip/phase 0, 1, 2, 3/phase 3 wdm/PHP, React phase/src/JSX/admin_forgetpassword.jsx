import React, { useState } from "react";
import pwdCSS from "../CSS/admin_forgetpassword.module.css";
import { Link } from "react-router-dom";
import axios from "axios";
import Url from "../BackendURL";

const ForgetPassword = () => {
	const [email, setEmail] = useState(""); // State for the email input

	const handleEmailChange = (e) => {
		setEmail(e.target.value);
	};

	const handleSubmit = (e) => {
		e.preventDefault();
		// Send the email for password reset here
		const formDetails = new FormData();
		formDetails.append("email", email);
		 axios
			.post(`${Url}api/forgotpass.php`, formDetails, {
				headers: {
					"Content-Type": "multipart/form-data", // Set the content type to multipart form data
				},
			})
			.then( (res) => {
				if (res.data === "User not registered") {
					alert("User not registered");
				}  else {
          alert("Email Sent");
				}
			})
			.catch((error) => {
				// Handle any errors that occur during the Axios request
				console.error("Error:", error);
			});
	};

	return (
		<div className={pwdCSS["pwd-body"]}>
			<div className={pwdCSS["pwd-container"]}>
				<h1 className={pwdCSS["pwd-h1"]}>Forget Password ?</h1>
				<form className={pwdCSS["pwd-form"]} action="/forgot-password" method="post" onSubmit={handleSubmit}>
					<label className={pwdCSS["pwd-label"]} htmlFor="email">
						Email:
					</label>
					<input className={pwdCSS["pwd-inputField"]} type="email" id="email" name="email" required value={email} onChange={handleEmailChange} />
					<h2 className={pwdCSS["pwd-h2"]}>The link for reset password will be sent to this email</h2>
					<button className={pwdCSS["pwd-button"]} type="submit">
						Submit
					</button>
				</form>
				<p className={pwdCSS["pwd-p"]}>
					Back to login Page?{" "}
					<Link to="/login" className={pwdCSS["pwd-a"]}>
						Log in
					</Link>
				</p>
			</div>
		</div>
	);
};

export default ForgetPassword;
