import React, {useState,useEffect} from "react";
import examCSS from "../CSS/student_examschedule.module.css";
import { Link,useParams } from 'react-router-dom'; // Make sure to adjust the import path if necessary
import axios from "axios";
import Url from "../BackendURL";
import { Session } from "../UserContext";

function StudentExamSchedule() {

  const {courseId} = useParams();
  const {userObject} = Session();
  const [data, setData] = useState([]);
  // eslint-disable-next-line
  const [examavail, setExamAvail] = useState(false);

  useEffect(() => {
    function getExamSchedule(){
      const formDetails = new FormData();
      formDetails.append('userId', userObject?.user_id);
      formDetails.append('courseId', courseId);
      axios.post(`${Url}api/getAllExams.php`,formDetails,{
        headers: {
          'Content-Type': 'multipart/form-data', // Set the content type to multipart form data
        },
      })
        .then((response) => {
          if(response.data === "No exam Available"){
            setExamAvail(false);
            console.log("No exams available");
          }else{
            setExamAvail(true);
            // console.log(response.data);
            setData(response.data);
          }
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    }
    // Make the HTTP request to the PHP file
    // eslint-disable-next-line react-hooks/exhaustive-deps
    if(userObject){

      getExamSchedule();
    }
    // eslint-disable-next-line
  }, [userObject]);




  return (
    <div className={examCSS["exam-body"]}>
     
      <h1 className={examCSS["exam-h1"]}>Exam Schedule</h1>
      <table className={examCSS["exam-table"]}>
        <thead>
          <tr>
            <th className={examCSS["exam-th"]}>Exam</th>
            <th className={examCSS["exam-th"]}>Availability</th>
            <th className={examCSS["exam-th"]}>Action</th>
          </tr>
        </thead>
        <tbody>

        { data.map((exam,index) => (
            <tr key={index}>
            <td className={examCSS["exam-td"]}>
             {exam.examTitle}
            </td>
            <td className={examCSS["exam-td"]}>{exam.examDate}</td>

            {!exam.score ? 
            <td className={examCSS["exam-td"]}>
              <button className={examCSS["exam-button"]}><Link to= {`/studentTakeExam/${exam.examId}/${courseId}`} style={{color:'white', textDecoration:'none'}}>Take Exam</Link></button>
            </td> : <td className={examCSS["exam-td"]}>Score  {": " + calculatePercentageGrade(exam.score,exam.total)}% </td> }
            </tr>
          ))}
    
      
        </tbody>
      </table>
    </div>
  );
}

function calculatePercentageGrade(score,total){
  const percentage = (score/total) * 100;
  return percentage;
}

export default StudentExamSchedule;
