import React, { useState, useEffect } from "react";
import axios from "axios";
import Url from "../BackendURL";
import { useParams,useNavigate } from "react-router-dom";
import { Session } from "../UserContext";

const StudentTakeExam = () => {

  const navigate = useNavigate();

  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const {userObject} = Session();
  const{examId,courseId} = useParams();
  

  useEffect(() => {
    // Fetch questions for the exam
    axios
      .get(`${Url}api/getQuestions.php?exam_id=${examId}`)
      .then((response) => {
        // Shuffle the options for each question
        const shuffledQuestions = response.data.map((question) => ({
          ...question,
          options: shuffleArray([
            question.option1,
            question.option2,
            question.option3,
            question.option4,
          ]),
        }));
        setQuestions(shuffledQuestions);
      })
      .catch((error) => {
        console.error("Error fetching questions:", error);
      });
  }, [examId]);

  const handleAnswerChange = (questionId, selectedOption) => {
    setAnswers({
      ...answers,
      [questionId]: selectedOption,
    });
  };

  const handleSubmitExam = () => {

    const unansweredQuestions = questions.filter(
      (question) => !answers[question.question_id]
    );

    if (unansweredQuestions.length > 0) {
      alert("Please answer all questions before submitting the exam.");
      return;
    }
    
    // Calculate the score based on the selected answers
    let correctAnswers = 0;
    questions.forEach((question) => {
      if (answers[question.question_id] === question.option1) {
        correctAnswers++;
      }
    });
    // Store the score in the database
    const formData = new FormData();
    formData.append("exam_id", examId);
    formData.append("user_id", userObject?.user_id);
    formData.append("course_id", courseId);
    formData.append("score", correctAnswers);

    axios
      .post(`${Url}api/submitExam.php`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((response) => {
        if (response.data === "Submission Successful") {
          navigate("/student_dashboard");
        }
      })
      .catch((error) => {
        console.error("Error submitting exam:", error);
      });
  };

   return (
    <div>
      <h1 style={{ textAlign: "center", margin: "20px" }}>Take Exam</h1>
      {questions.map((question,index) => (
        <div key={index} style={{ margin: "20px" }}>
          <p style={{ fontWeight: "bold" }}>{(index+1) + ". " + question.question}</p>
          {question.options.map((option,optionIndex) => (
            <div key={optionIndex} style={{ margin: "10px" }}>
              <label>
                <input
                  type="radio"
                  name={`question_${question.question_id}`}
                  value={option}
                  onChange={() =>
                    handleAnswerChange(question.question_id, option)
                  }
                  checked={answers[question.question_id] === option}
                />
                <span style={{ marginLeft: "10px" }}>{option}</span>
              </label>
            </div>
          ))}
        </div>
      ))}
      <button
        onClick={handleSubmitExam}
        style={{
          backgroundColor: "green",
          color: "white",
          padding: "10px 20px",
          border: "none",
          cursor: "pointer",
          margin: "20px",
        }}
      >
        Submit Exam
      </button>
    </div>
  );
};

// Function to shuffle an array
function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

export default StudentTakeExam;
