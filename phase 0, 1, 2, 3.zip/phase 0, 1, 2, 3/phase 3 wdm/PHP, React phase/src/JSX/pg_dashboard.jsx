import React from "react";
import dashboardCSS from "../CSS/pg_dashboard.module.css";
import { Link } from 'react-router-dom'; // Make sure to adjust the import path if necessary

const Dashboard = () => {
  return (
    <div className={`${dashboardCSS["dashb-body"]}`}>


      <div className={`${dashboardCSS["dashboard"]}`}>
        <div
          className={`${dashboardCSS["tile"]} ${dashboardCSS["performance-tile"]}`}
        >
          <h2 className={`${dashboardCSS["tileh2"]}`}>Student Performance</h2>
          <p>Monitor student performance data here.</p>
          <Link to="/pg_performance" className={dashboardCSS["click-button"]}>
            Click Here
          </Link>
        </div>
        <div
          className={`${dashboardCSS["tile"]} ${dashboardCSS["performance-tile"]}`}
        >
          <h2 className={`${dashboardCSS["tileh2"]}`}>My Program</h2>
          <p>Monitor courses here.</p>
          <Link to="/pc_courses" className={dashboardCSS["click-button"]}>
            Click Here
          </Link>
        </div>
        <div
          className={`${dashboardCSS["tile"]} ${dashboardCSS["performance-tile"]}`}
        >
          <h2>Student Concerns</h2>
          <p>See all the queries from students here</p>
          <Link to="/pg_studentconcern" className={dashboardCSS["click-button"]}>
            Click Here
          </Link>
        </div>


      </div>
    </div>
  );
};

export default Dashboard;
