import React, {useState,useEffect} from "react";
import styles from "../CSS/student_feedback.module.css";
import {  useParams } from 'react-router-dom'; // Make sure to adjust the import path if necessary
import axios from "axios";
import Url from "../BackendURL";
import { Session } from "../UserContext";

function StudentFeedback() {

  const {courseId} = useParams();
  const {userObject} = Session();
  const [formData, setFormData] = useState({
    email: "",
    role:"instructor",
    message:"",
    rating: "",
    from: userObject?.user_id
  });

  useEffect(() => {
    function getInstructorInfo(){
      const formDetails = new FormData();
      formDetails.append('courseId', courseId);
      axios.post(`${Url}api/getInstructorInfo.php`,formDetails,{
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      })
        .then((response) => {
          setFormData({ ...formData, email: response.data['email']});
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    }
    // Make the HTTP request to the PHP file
    getInstructorInfo();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  const handleSignup = async (e) => {
    e.preventDefault();
    const formDetails = new FormData();
    formDetails.append('email', formData.email);
    formDetails.append('message', "Gave Rating " + formData.rating + " : " + formData.message);
    formDetails.append('from', formData.from);
    formDetails.append('role', formData.role);
    await axios.post(`${Url}api/message.php`, formDetails, {
      headers: {
        'Content-Type': 'multipart/form-data', // Set the content type to multipart form data
      },
    })
    .then(async (res) => {
      if (res.data === 'User Not Found'){
        alert('User Not Found');
      }else{
        setFormData({ ...formData, email: "",role:"", message:"", });
        alert('Message Sent');
        console.log(res.data);
      }


    })
    .catch((error) => {
      // Handle any errors that occur during the Axios request
      console.error('Error:', error);
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };


  return (
    <div className={styles["fed-body"]}>
      
      <div className={styles["student-container"]}>
        <h2>Feedback Form</h2>
        <form onSubmit={handleSignup}>
          <br />
          <input
            type="radio"
            id="instructor"
            name="feedbackType"
            value="Instructor"
            defaultChecked
          />
          <label htmlFor="instructor">Instructor</label>
          <br />

          <p>Select Rating:</p>
          <input type="radio" id="excellent" name="rating" value="Excellent" onChange={handleInputChange} />
          <label htmlFor="excellent">Excellent</label>
          <br />
          <input type="radio" id="Good" name="rating" value="Good" onChange={handleInputChange} />
          <label htmlFor="good">Good</label>
          <br />
          <input type="radio" id="bad" name="rating" value="Bad"  onChange={handleInputChange}/>
          <label htmlFor="bad">Bad</label>
          <br />

          <p>Feedback:</p>
          <textarea
            id="feedback"
            name="message"
            rows="4"
            cols="50"
            value = {formData.message}
            onChange={handleInputChange}
            required
          ></textarea>

          <input type="submit" value="Submit Feedback" />
        </form>
      </div>
    </div>
  );
}

export default StudentFeedback;
