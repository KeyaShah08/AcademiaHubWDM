import React, { useState, useEffect } from "react";
import profileCSS from "../CSS/qa_profile.module.css";
import { Session } from "../UserContext";
import axios from "axios";
import Url from "../BackendURL";

const QA_ProfilePage = () => {
	const { userObject, login } = Session();
	const [formData, setFormData] = useState({
		name: "",
		email: "",
		role: "",
	});

	const [currentPassword, setCurrentPassword] = useState("");
	const [newPassword, setNewPassword] = useState("");

	const handleCurrentPasswordChange = (e) => {
		setCurrentPassword(e.target.value);
	};

	const handleNewPasswordChange = (e) => {
		setNewPassword(e.target.value);
	};
	const handleInputChange = (e) => {
		const { name, value } = e.target;
		setFormData({
			...formData,
			[name]: value,
		});
	};
	useEffect(() => {
		if (userObject) {
			setFormData({
				name: userObject.name || "",
				email: userObject.email || "",
				role: userObject.role || "",
			});
		}
	}, [userObject]);

	const handleSubmit = (e) => {
		e.preventDefault();
		const formDetails = new FormData();
		formDetails.append("name", formData.name);
		formDetails.append("email", formData.email);

		axios
			.post(`${Url}api/changename.php`, formDetails, {
				headers: {
					"Content-Type": "multipart/form-data", // Set the content type to multipart form data
				},
			})
			.then((response) => {
				console.log(response.data);
				login(response.data);
			})
			.catch((error) => {
				console.error("Error fetching data:", error);
			});
	};

	const changePass = (e) => {
    e.preventDefault();

    const formDetails = new FormData();
		formDetails.append("old", currentPassword);
    formDetails.append("new", newPassword);
		formDetails.append("email", formData.email);

		axios
			.post(`${Url}api/changepassword.php`, formDetails, {
				headers: {
					"Content-Type": "multipart/form-data", // Set the content type to multipart form data
				},
			})
			.then((response) => {
				alert(response.data);
				
			})
			.catch((error) => {
				console.error("Error fetching data:", error);
			});
  };

	return (
		<div className={profileCSS["prof-body"]}>
			<div className={profileCSS["profile-container"]}>
				<h1>Profile</h1>
				<section id="profile" className={profileCSS["profile-section"]}>
					<h2>Profile Information</h2>
					<form onSubmit={handleSubmit}>
						<div className={profileCSS["profile-item"]}>
							<label htmlFor="name">Name:</label>
							<input type="text" id="name" name="name" value={formData.name} onChange={handleInputChange} />
						</div>
						<div className={profileCSS["profile-item"]}>
							<label htmlFor="email">Email:</label>
							<input type="email" id="email" name="email" value={formData.email} disabled />
						</div>
						<div className={profileCSS["profile-item"]}>
							<label htmlFor="role">Role:</label>
							<input type="text" id="role" name="role" value={formData.role} disabled />
						</div>
						<div className={profileCSS["profile-item"]}>
							<button className={profileCSS["profile-button"]} type="submit">
								Save Changes
							</button>
						</div>
					</form>
				</section>
				<section id="change-password" className={profileCSS["profile-section"]}>
					<h2>Change Password</h2>
					<form onSubmit={changePass}>
						<div>
							<label htmlFor="current-password">Current Password:</label>
							<input type="password" id="current-password" name="current-password" value={currentPassword} onChange={handleCurrentPasswordChange} required />
						</div>
						<div>
							<label htmlFor="new-password">New Password:</label>
							<input type="password" id="new-password" name="new-password" value={newPassword} onChange={handleNewPasswordChange} required />
						</div>
						<div>
							<button type="submit">Change Password</button>
						</div>
					</form>
				</section>
			</div>
		</div>
	);
};

export default QA_ProfilePage;
