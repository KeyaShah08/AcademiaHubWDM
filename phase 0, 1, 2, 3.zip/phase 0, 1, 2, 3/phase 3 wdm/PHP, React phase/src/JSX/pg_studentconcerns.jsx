import axios from "axios";
import Url from "../BackendURL";
import React, {useState, useEffect} from "react";import studentconcernCSS from "../CSS/pg_studentconcerns.module.css";

const StudentConcerns = () => {
  const [data, setData] = useState([]);
  useEffect(()=>{

			axios
				.get(`${Url}api/getcontact.php`)
				.then((response) => {
					setData(response.data);
				})
				.catch((error) => {
					console.error("Error fetching data:", error);
				});
  },[]);

  const handleClick = (msg) => {
    const formDetails = new FormData();
    formDetails.append("message", msg);
    axios
				.post(`${Url}api/resolvecontact.php`, formDetails, {
					headers: {
						"Content-Type": "multipart/form-data",
					},
				})
				.then(() => {
					window.location.reload();

				})
				.catch((error) => {
					console.error("Error fetching data:", error);
				});
  }
  return (
    <div className={`${studentconcernCSS["conc-body"]}`}>

      <div className={`${studentconcernCSS["studentconcern-container"]}`}>
        <ul className={`${studentconcernCSS["queries-list"]}`}>
        {data.map((response, index) => (
								<li key={index}>
                  {response.name}
                  <br/><br/><br/><br/><br/><br/>
                <span className={`${studentconcernCSS["query"]}`}>
                  {response.email}: {response.message}
                </span>
                {response.resolved === "0"?  <button onClick={() => handleClick(response.message)} className={`${studentconcernCSS["resolve-button"]}`}>
                  Resolve
                </button> : <div>Resolved</div>}
               
              </li>
							))}
          
        </ul>
      </div>
    </div>
  );
};

export default StudentConcerns;
