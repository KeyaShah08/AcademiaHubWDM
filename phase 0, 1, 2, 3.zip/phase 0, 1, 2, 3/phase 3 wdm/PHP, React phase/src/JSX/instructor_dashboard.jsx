import React, { useState, useEffect } from "react";
import dashboardCSS from "../CSS/instructor_dashboard.module.css";
import { Link} from 'react-router-dom'; // Make sure to adjust the import path if necessary
import axios from "axios";
import Url from "../BackendURL";
import { Session } from "../UserContext";


const InstructorDashboard = () => {

  const { userObject } = Session();
  const [data, setData] = useState([]);

  useEffect(() => {
    function getCourses(){
      const formDetails = new FormData();
      formDetails.append('instructorId', userObject?.user_id);
      axios.post(`${Url}api/instructorMyCourses.php`,formDetails,{
        headers: {
          'Content-Type': 'multipart/form-data', // Set the content type to multipart form data
        },
      })
        .then((response) => {
          setData(response.data);
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    }
    // Make the HTTP request to the PHP file
    // eslint-disable-next-line react-hooks/exhaustive-deps
    if(userObject){

      getCourses();
    }
  }, [userObject]);

  

  return (
    <div className={dashboardCSS["instr-body"]}>
      <br />
      <div className={dashboardCSS["instr-tile"]}>
        <h1>My Courses</h1>
        <div className={dashboardCSS["dropdown"]}>
          <button className={dashboardCSS["dropbtn"]}>View My Courses</button>
          <div className={dashboardCSS["dropdown-content"]}>
          {
            data.map( (course,index) =>(
              <div key={index}>
              <Link to={`/instructor_course_objective/${course.courseId}`}>{course.courseName}</Link>
              </div>
            ))
          }
          </div>
        </div>
      </div>
      <div className={dashboardCSS["instr-tile"]}>
        <h1>Create Exam</h1>
        <div className={dashboardCSS["dropdown"]}>
          <button className={dashboardCSS["dropbtn"]}>View My Courses</button>
          <div className={dashboardCSS["dropdown-content"]}>
          {
            data.map( (course,index) =>(
              <div key={index}>
              <Link to={`/instructor_create_exam/${course.courseId}`}>{course.courseName}</Link>
              </div>
            ))
          }
          </div>
        </div>
      </div>
      <div className={dashboardCSS["instr-tile"]}>
        <h1>Grade Exam</h1>
        <div className={dashboardCSS["dropdown"]}>
          <button className={dashboardCSS["dropbtn"]}>Select Course</button>
          <div className={dashboardCSS["dropdown-content"]}>
          {
            data.map( (course,index) =>(
              <div key={index}>
              <Link to={`/instructor_grade_exam/${course.courseId}`}>{course.courseName}</Link>
              </div>
            ))
          }
          </div>
        </div>
      </div>
      <div className={dashboardCSS["instr-tile"]}>
        <h1>Student Progress</h1>
        <div className={dashboardCSS["dropdown"]}>
          <button className={dashboardCSS["dropbtn"]}>Select Course</button>
          <div className={dashboardCSS["dropdown-content"]}>
          {
            data.map( (course,index) =>(
              <div key={index}>
              <Link to={`/instructor_student_performance/${course.courseId}`}>{course.courseName}</Link>
              </div>
            ))
          }
          </div>
        </div>
      </div>
      <br />
      <br />

      <div className={dashboardCSS["chat-container"]}>
        <div className={dashboardCSS["chat-header"]}>Help Desk Chat Bot</div>
        <div className={dashboardCSS["chat-messages"]}></div>
        <div className={dashboardCSS["chat-input"]}>
          <input type="text" placeholder="Type your message..." />
          <button className={dashboardCSS["send-button"]}>Send</button>
        </div>
      </div>
    </div>
  );
};

export default InstructorDashboard;
