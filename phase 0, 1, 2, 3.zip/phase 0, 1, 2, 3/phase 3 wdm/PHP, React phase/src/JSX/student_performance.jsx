import performanceCSS from "../CSS/pg_performance.module.css";
import axios from "axios";
import Url from "../BackendURL";
import React, { useState, useEffect } from "react";
import { Session } from "../UserContext.js";
import {  useParams } from 'react-router-dom'; // Make sure to adjust the import path if necessary

const StudentPerformance = () => {
    const {courseid} = useParams();
    const { userObject } = Session();
	const [data, setData] = useState([]);
	useEffect(() => {
        if(userObject){
            const formDetails = new FormData();
            formDetails.append('id', userObject?.user_id);
            formDetails.append('courseid', courseid);
            axios.post(`${Url}api/getstudentperformance.php`,formDetails,{
              headers: {
                'Content-Type': 'multipart/form-data',
              },
            })
			.then((response) => {
                setData(response.data);
			})
			.catch((error) => {
                console.error("Error fetching data:", error);
			});
        }
	}, [userObject]);
	return (
		<div className={`${performanceCSS["perf-body"]}`}>
			<div className={`${performanceCSS["dashboard"]}`}>
				<div className={`${performanceCSS["report"]}`}>
					<h2 className={`${performanceCSS["performance-h2"]}`}>Performance Report</h2>
					<table className={`${performanceCSS["performance-table"]}`}>
						<thead>
							<tr>
								<th className={`${performanceCSS["performance-th"]}`}>Exam</th>
								<th className={`${performanceCSS["performance-th"]}`}>Grade</th>
							</tr>
						</thead>
						<tbody>
                        {data.map((report, index) => (
								<tr key={index}>
									  <td className={`${performanceCSS["performance-td"]}`}>
                  {report.title}
                </td>
                <td className={`${performanceCSS["performance-td"]}`}>{((report.score / report.total) * 100).toFixed(2)}%</td>

              </tr>
							))}
						</tbody>
					</table>
				</div>
			</div>
		</div>
	);
};

export default StudentPerformance;
