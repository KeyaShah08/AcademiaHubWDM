import performanceCSS from "../CSS/pg_performance.module.css";
import { Link } from 'react-router-dom'; // Make sure to adjust the import path if necessary
import axios from "axios";
import Url from "../BackendURL";
import React, {useState, useEffect} from "react";

const PerformanceDashboard = () => {
  const [data, setData] = useState([]);
  useEffect(()=>{

			axios
				.get(`${Url}api/pcreports.php`)
				.then((response) => {
					setData(response.data);
				})
				.catch((error) => {
					console.error("Error fetching data:", error);
				});
  },[]);
  return (
    <div className={`${performanceCSS["perf-body"]}`}>

      <div className={`${performanceCSS["dashboard"]}`}>
        <div className={`${performanceCSS["report"]}`}>
          <h2 className={`${performanceCSS["performance-h2"]}`}>
            Student Performance Report
          </h2>
          <table className={`${performanceCSS["performance-table"]}`}>
            <thead>
              <tr>
                <th className={`${performanceCSS["performance-th"]}`}>
                  Student Name
                </th>
                <th className={`${performanceCSS["performance-th"]}`}>Grade</th>

                <th className={`${performanceCSS["performance-th"]}`}>
                  Feedback
                </th>
              </tr>
            </thead>
            <tbody>
               
              {data.map((report, index) => (
								<tr key={index}>
									  <td className={`${performanceCSS["performance-td"]}`}>
                  {report.name}
                </td>
                <td className={`${performanceCSS["performance-td"]}`}>{((report.total_score / report.total_exam_total) * 100).toFixed(2)}%</td>
                <td className={`${performanceCSS["performance-td"]}`}>
                  <Link to="/message"
                    className={`${performanceCSS["feedback-button"]}`}
                  >
                    Give Feedback
                  </Link>
                </td>
              </tr>
							))}
              
            </tbody>
          </table>
        </div>


      </div>
    </div>
  );
};

export default PerformanceDashboard;
