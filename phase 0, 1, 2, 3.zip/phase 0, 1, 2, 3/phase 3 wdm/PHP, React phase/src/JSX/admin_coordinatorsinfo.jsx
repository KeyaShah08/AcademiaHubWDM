import React from "react";
import infoCSS from "../CSS/admin_coordinatorsinfo.module.css";
import { Link } from 'react-router-dom'; // Make sure to adjust the import path if necessary


const CoordinatorInfo = () => {
  return (
    <div className={infoCSS["info-body"]}>
      <div className={infoCSS["navbar"]}>
        <span className={infoCSS["navbar-title"]}>
          Welcome to the Coordinator's Information Page
        </span>
        <Link to="/admin_admin">Dashboard</Link>
      </div>
      <br />
      <br />
      <main>
        <section>
          <h2 className={infoCSS["info-h2"]}>Coordinator's Details</h2>
          <table className={infoCSS["pcinfotable"]}>
            <thead>
              <tr>
                <th className={infoCSS["pcinfotable-th"]}>Name</th>
                <th className={infoCSS["pcinfotable-th"]}>Email</th>
                <th className={infoCSS["pcinfotable-th"]}>User ID</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className={infoCSS["pcinfotable-td"]}>
                  <Link to="/admin_coordinator1"
                    title="Total credits: 39, Completed Credit: 21, GPA: 3.78"
                  >
                    Azura Kalliope
                  </Link>
                </td>
                <td className={infoCSS["pcinfotable-td"]}>
                  azura.kalliope@example.com
                </td>
                <td className={infoCSS["pcinfotable-td"]}>24680</td>
              </tr>
              <tr>
                <td className={infoCSS["pcinfotable-td"]}>
                  <Link to="/admin_coordinator2"
                    title="Total credits: 45, Completed Credit: 33, GPA: 3.3"
                  >
                    Thaddeus Whitaker
                  </Link>
                </td>
                <td className={infoCSS["pcinfotable-td"]}>
                  thaddeus.whitaker@example.com
                </td>
                <td className={infoCSS["pcinfotable-td"]}>13579</td>
              </tr>
            </tbody>
          </table>
        </section>
      </main>
    </div>
  );
};

export default CoordinatorInfo;
