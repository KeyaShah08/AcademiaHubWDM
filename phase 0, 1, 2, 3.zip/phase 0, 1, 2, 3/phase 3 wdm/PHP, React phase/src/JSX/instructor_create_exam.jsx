import React, { useState, useEffect } from "react";
// import examCSS from "../CSS/instructor_create_exam.module.css";
import { useParams } from "react-router-dom";
import axios from "axios";
import Url from "../BackendURL";

const InstructorCreateExam = () => {

	const { courseid } = useParams();
	const [examTitle, setExamTitle] = useState("");
	const [examDate, setExamDate] = useState("");
	const [questions, setQuestions] = useState([{ question: "", options: ["", "", "", ""] }]);

	useEffect(() => {
		// Get today's date
		const today = new Date();
	
		// Format the date as "YYYY-MM-DD" (e.g., "2023-10-26")
		const year = today.getFullYear();
		const month = String(today.getMonth() + 1).padStart(2, "0"); // Month is zero-based
		const day = String(today.getDate()).padStart(2, "0");
	
		const formattedDate = `${year}-${month}-${day}`;
	
		// Set the formatted date in the state
		setExamDate(formattedDate);
	  }, []);

	const addQuestion = () => {
		setQuestions([...questions, { question: "", options: ["", "", "", ""] }]);
	};
	const deleteLastQuestion = () => {
		if (questions.length > 1) {
			const updatedQuestions = [...questions];
			updatedQuestions.pop(); // Remove the last question
			setQuestions(updatedQuestions);
		}
	};

	const handleQuestionChange = (index, event) => {
		const newQuestions = [...questions];
		newQuestions[index].question = event.target.value;
		setQuestions(newQuestions);
	};

	const handleOptionChange = (questionIndex, optionIndex, event) => {
		const newQuestions = [...questions];
		newQuestions[questionIndex].options[optionIndex] = event.target.value;
		setQuestions(newQuestions);
	};

	const handleCreate = async () => {
		if(examTitle.length === 0){
			alert("Missing Fields");
			return
		}

		for (const question of questions) {
			if (!question.question || question.question.trim() === '') {
				alert("Missing Fields");
				return
			}
		
			for (const option of question.options) {
			  if (!option || option.trim() === '') {
				alert("Missing Fields");
				return
			  }
			}
		  }

		const formData = new FormData();
		const currentDate = new Date();
		const selectedDate = new Date(examDate);
		if (selectedDate <= currentDate) {
			alert("Please select an exam date that is ahead of the current date.");
			return;
		}	
		formData.append("title", examTitle);
		formData.append("date", examDate);
		formData.append("course_id", parseInt(courseid));
		formData.append("total", parseInt(questions.length));
		await axios
			.post(`${Url}api/createexam.php`, formData, {
				headers: {
					"Content-Type": "multipart/form-data", // Set the content type to multipart form data
				},
			})
			.then(async (res) => {
				if (res.data === "Creation Failed") {
					alert("Creation Failed");
				} else {
					console.log(res.data);
					questions.forEach(async (questionElement) => {
						const questionData = new FormData();
						questionData.append(`exam_id`, res.data);
						questionData.append(`question`, questionElement.question);
						questionElement.options.forEach((option, optionIndex) => {
							questionData.append(`option${optionIndex + 1}`, option);
						});
						console.log(questionElement);
						await axios
							.post(`${Url}api/createquestion.php`, questionData, {
								headers: {
									"Content-Type": "multipart/form-data", // Set the content type to multipart form data
								},
							})
							.then(() => {
								alert("Exam Created");
								setExamDate("");
								setExamTitle("");
								setQuestions([{ question: "", options: ["", "", "", ""] }]);
							});
					});
				}
			})
			.catch((error) => {
				// Handle any errors that occur during the Axios request
				console.error("Error:", error);
			});
	};

	return (
		<div style={{ padding: "20px", display: "flex", flexDirection: "column" }}>
			<h1>Create a Quiz</h1>

			<label>Exam Title:</label>
			<input type="text" value={examTitle} onChange={(e) => setExamTitle(e.target.value)} style={{ marginBottom: "10px", width: "300px" }} />

			<label>Exam Date:</label>
			<input type="date" value={examDate} onChange={(e) => setExamDate(e.target.value)} style={{ marginBottom: "20px", display: "block", width: "300px" }} />
			<div>Option1  will be taken as the correct answer</div>

			{questions.map((question, questionIndex) => (
				<div key={questionIndex} style={{ marginBottom: "20px" }}>
					<label>Question {questionIndex + 1}:</label>
					<input type="text" value={question.question} onChange={(e) => handleQuestionChange(questionIndex, e)} style={{ marginBottom: "10px", display: "block" }} />

					{question.options.map((option, optionIndex) => (
						<div key={optionIndex}>
						<label>Option {optionIndex + 1}:</label>
						<input
							key={optionIndex}
							type="text"
							value={option}
							onChange={(e) => handleOptionChange(questionIndex, optionIndex, e)}
							style={{ marginBottom: "5px", display: "block" }}
						/>
						</div>
					))}
				</div>
			))}
			<div style={{ display: "flex", flexDirection: "row", justifyContent: "space-between" }}>
				<button onClick={addQuestion} style={{ background: "green", color: "white", fontSize: "20px" }}>
					Add Question
				</button>
				<button onClick={deleteLastQuestion} style={{ background: "green", color: "white", fontSize: "20px" }}>
					Delete Last Question
				</button>

				<button onClick={handleCreate} style={{ float: "right", background: "green", color: "white", fontSize: "20px" }}>
					Create Exam
				</button>
			</div>
		</div>
	);
};

export default InstructorCreateExam;
