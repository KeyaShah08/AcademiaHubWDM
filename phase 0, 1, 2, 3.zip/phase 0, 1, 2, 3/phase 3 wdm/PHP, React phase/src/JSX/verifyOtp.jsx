import React, { useState } from "react";
import loginCSS from "../CSS/admin_login.module.css";
import university from "../FILES/university.jpg";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Url from "../BackendURL";
import { Session } from "../UserContext";
const VerifyOtp = () => {
	const navigate = useNavigate();

	const { userObject, login } = Session();

	const [formData, setFormData] = useState({
		otp: "",
	});

	const handleVerify = async (e) => {
		e.preventDefault();
		const formDetails = new FormData();
		formDetails.append("otp", formData.otp);
		formDetails.append("email", userObject.email);
		await axios
			.post(`${Url}api/otp.php`, formDetails, {
				headers: {
					"Content-Type": "multipart/form-data", // Set the content type to multipart form data
				},
			})
			.then(async (res) => {
				if (res.data === "Incorrect OTP") {
					alert("Incorrect OTP");
				} else if (res.data === "Failed to update email verification status") {
					alert("Failed to update email verification status");
				} else {
					await login(res.data);
					if(res.data.role === 'student'){
						navigate("/student_dashboard");
					}
					else if(res.data.role === 'admin'){
						navigate("/admin_admin");
					}
					else if (res.data.role === 'instructor'){
						navigate("/instructor_dashboard");
					}
					else if(res.data.role === 'pc'){
						navigate("/pg_dashboard");
					}
					else{
						navigate("/qa_dashboard");
					}
				}
			})
			.catch((error) => {
				// Handle any errors that occur during the Axios request
				console.error("Error:", error);
			});
	};

	const handleInputChange = (e) => {
		const { name, value } = e.target;
		setFormData({
			...formData,
			[name]: value,
		});
	};
	return (
		<div className={`${loginCSS["login-body"]}`}>
			<img src={university} alt="University" className={loginCSS["background-image"]} />
			<div className={`${loginCSS["login-container"]}`}>
				<h1 className={`${loginCSS["login-h1"]}`}>Verify OTP</h1>
				<form className={`${loginCSS["login-form"]}`} onSubmit={handleVerify}>
					<input className={`${loginCSS["login-inputField"]}`} type="text" name="otp" placeholder="OTP" onChange={handleInputChange} required />
					<button type="submit" className={loginCSS["login-button"]}>
						Verify
					</button>
				</form>
			</div>
		</div>
	);
};

export default VerifyOtp;
