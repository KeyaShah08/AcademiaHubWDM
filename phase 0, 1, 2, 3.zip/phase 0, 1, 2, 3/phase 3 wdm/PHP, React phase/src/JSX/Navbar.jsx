import React from "react";
import QA_DashboardCSS from "../CSS/qa_dashboard.module.css";
import { Link } from "react-router-dom";
import { Session } from "../UserContext";

const Navbar = () => {
	const { userObject, logout } = Session();

	return (
		<div className={QA_DashboardCSS["navbar"]}>
			<span className={QA_DashboardCSS["navbar-title"]}>AcademiaHub</span>
			{userObject ? (
				<Link onClick={logout} to={"/login"}>
					SignOut
				</Link>
			) : (
				<Link to={"/login"}>SignIn</Link>
			)}
			{userObject && (
				<div>
					<Link to="/profile">My Profile</Link>
					<Link to="/message">Message</Link>
					<Link to="/notifications">Notifications</Link>
				</div>
			)}
			{!userObject && (
				<div>
					<Link to="/services">Service Page</Link>
					<Link to="/aboutus">About Us</Link>
					<Link to="/contactus">Contact Us</Link>
					<Link to="https://kxs9489.uta.cloud/">Blog</Link>
				</div>
			)}
			{userObject?.role === "student" && <Link to="/student_dashboard">Dashboard</Link>}
			{userObject?.role === "admin" && <Link to="/admin_admin">Dashboard</Link>}
			{userObject?.role === "instructor" && <Link to="/instructor_dashboard">Dashboard</Link>}
			{userObject?.role === "qa" && <Link to="/qa_dashboard">Dashboard</Link>}
			{userObject?.role === "pc" && <Link to="/pg_dashboard">Dashboard</Link>}
			{!userObject && <Link to="/">Homepage</Link>}
		</div>
	);
};

export default Navbar;
