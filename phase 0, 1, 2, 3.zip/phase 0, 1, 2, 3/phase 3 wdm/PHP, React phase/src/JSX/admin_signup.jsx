import React, { useState } from "react";
import signupCSS from "../CSS/admin_signup.module.css";
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';
import Url from "../BackendURL";
import { Session } from "../UserContext";


const UniversitySignUp = () => {
  const {login} = Session();

  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "student",
  });

  const handleSignup = async (e) => {
    e.preventDefault();
    const formDetails = new FormData();
    formDetails.append('email', formData.email);
    formDetails.append('password', formData.password);
    formDetails.append('name', formData.name);
    formDetails.append('role', formData.role);
    await axios.post(`${Url}api/signup.php`, formDetails, {
      headers: {
        'Content-Type': 'multipart/form-data', // Set the content type to multipart form data
      },
    })
    .then(async (res) => {
      if (res.data === 'User already registered'){
        alert('User already registered');
      }
      else if( res.data === 'Registration Failed'){
        alert('Registration Failed');
      }
      else{
        await login(res.data);
        navigate("/verify");
      }
    })
    .catch((error) => {
      // Handle any errors that occur during the Axios request
      console.error('Error:', error);
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  return (
    <div className={signupCSS["signup-body"]}>
      <div className={signupCSS["signup-container"]}>
        <h1 className={signupCSS["signup-h1"]}>University Sign-Up</h1>
        <form className={signupCSS["form"]} onSubmit={handleSignup}>
          <label className={signupCSS["signup-label"]} htmlFor="full_name">
            Full Name:
          </label>
          <input
            className={signupCSS["inputField"]}
            type="text"
            id="name"
            name="name"
            required
            onChange={handleInputChange}
          />

          <label className={signupCSS["signup-label"]} htmlFor="email">
            Email:
          </label>
          <input
            className={signupCSS["inputField"]}
            type="email"
            id="email"
            name="email"
            required
            onChange={handleInputChange}
          />
          <label className={signupCSS["signup-label"]} htmlFor="email">
            Phone:
          </label>
          <input
            className={signupCSS["inputField"]}
            type="text"
            id="phone"
            name="phone"
            pattern="[0-9]{10}"
            required
          />

          <label className={signupCSS["signup-label"]} htmlFor="password">
            Password:
          </label>
          <input
            className={signupCSS["inputField"]}
            type="password"
            id="password"
            name="password"
            required
            onChange={handleInputChange}
          />

          <label className={signupCSS["signup-label"]} htmlFor="role">
            I am a:
          </label>
          <select className={signupCSS["selectRole"]} id="role" name="role" onChange={handleInputChange}>
            <option className={signupCSS["optionRole"]} value="student">
              Student
            </option>
            <option className={signupCSS["optionRole"]} value="instructor">
              Instructor
            </option>
            <option className={signupCSS["optionRole"]} value="qa">
              QA officer
            </option>
            <option
              className={signupCSS["optionRole"]}
              value="pc"
            >
              Program Co-ordinator
            </option>
          </select>

          
          <button className={signupCSS["signup-button"]} type="submit">
            Sign Up
          </button>
        </form>

        <p className={signupCSS["signup-p"]}>
          Already have an account?{" "}
          <Link to="/login" className={signupCSS["signup-a"]}>
            Log in
          </Link>
        </p>
      </div>
    </div>
  );
};

export default UniversitySignUp;
