import React, { useState, useEffect } from "react";
import monitorCSS from "../CSS/admin_monitor.module.css";
import axios from "axios";
import Url from "../BackendURL";
const ActivityPage = () => {
	const [data, setData] = useState([]);

	useEffect(() => {
		function getLogins() {
			axios
				.get(`${Url}api/monitor.php`)
				.then((response) => {
					setData(response.data);
				})
				.catch((error) => {
					console.error("Error fetching data:", error);
				});
		}

		// Make the HTTP request to the PHP file
		getLogins();
	}, []);

	return (
		<div className={monitorCSS["monitor-body"]}>
			<h2 className={monitorCSS["monitor-h2"]}>User Table</h2>
			<table className={monitorCSS["monitor-t1"]}>
				<thead>
					<tr>
						<th className={monitorCSS["monitor-th"]}>Email</th>
						<th className={monitorCSS["monitor-th"]}>Role</th>
						<th className={monitorCSS["monitor-th"]}>Logged In at</th>
					</tr>
				</thead>
				<tbody>
					{data.map((user,index) => (
						<tr key={index}>
							<td className={monitorCSS["monitor-td"]}>{user.email}</td>
							<td className={monitorCSS["monitor-td"]}>{user.role}</td>
							<td className={monitorCSS["monitor-td"]}>{user.login}</td>
						</tr>
					))}
				</tbody>
			</table>
		</div>
	);
};

export default ActivityPage;
