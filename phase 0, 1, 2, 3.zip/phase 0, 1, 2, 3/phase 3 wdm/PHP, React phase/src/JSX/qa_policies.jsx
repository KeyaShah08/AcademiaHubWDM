import React, { useState, useEffect } from "react";
import policyCSS from "../CSS/qa_policies.module.css";
import axios from "axios";
import Url from "../BackendURL";

function QA_POLICIES() {
	const [data, setData] = useState([]);
	useEffect(() => {
		axios
			.get(`${Url}api/getpolicies.php`)
			.then((response) => {
				setData(response.data);
			})
			.catch((error) => {
				console.error("Error fetching data:", error);
			});
	}, []);

	const handleSubmit = (e, id, policy) => {
    e.preventDefault();		const formDetails = new FormData();
		formDetails.append("id", id);
		formDetails.append("desc", policy.desc);
		formDetails.append("title", policy.title);
		axios
			.post(`${Url}api/updatepolicy.php`, formDetails, {
				headers: {
					"Content-Type": "multipart/form-data", // Set the content type to multipart form data
				},
			})
			.then((response) => {
			  alert(response.data);
			})
			.catch((error) => {
				console.error("Error fetching data:", error);
			});
	};

  const handleEditTitle = (e, index) => {
    const updatedData = [...data];
    updatedData[index].title = e.target.value;
    setData(updatedData);
  };

  const handleEditDesc = (e, index) => {
    const updatedData = [...data];
    updatedData[index].desc = e.target.value;
    setData(updatedData);
  };
	return (
		<div className={policyCSS["policy-body"]}>
			<div className={policyCSS["qa-container"]}>
				<h1>List of Policies</h1>
				<ul className={policyCSS["policy-list"]}>
					{data.map((policy, index) => (
						<li className={policyCSS["policy-list-li"]} key={index}>
							<form onSubmit={(e) => handleSubmit(e, policy.id, data[index])}>
								<input
									type="text"
									value={policy.title}
									onChange={(e) => handleEditTitle(e, index)}
									style={{
										border: "1px solid #ccc",
										padding: "8px",
										width: "300px",
									}}
								/>
								<br />
								<textarea
									value={policy.desc}
									onChange={(e) => handleEditDesc(e, index)}
									style={{
										border: "1px solid #ccc",
										padding: "8px",
										width: "95%",
										height: "100px",
									}}
								/>
								<div className={policyCSS["policy-list-li-actions"]}>
									<button type="submit" className={policyCSS["qa-button"]}>
										Submit
									</button>
								</div>
							</form>
						</li>
					))}
				</ul>
			</div>
		</div>
	);
}

export default QA_POLICIES;
