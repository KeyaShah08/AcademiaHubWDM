import React, {useState, useEffect} from "react";
import ReportCSS from "../CSS/qa_report.module.css";
import { Link } from "react-router-dom";
import axios from "axios";
import Url from "../BackendURL";
import { useParams } from "react-router-dom";


function QA_REPORT() {
  const { courseid } = useParams();
  const [data, setData] = useState([]);
  useEffect(()=>{
    const formDetails = new FormData();
			formDetails.append("course_id", courseid);
			axios
				.post(`${Url}api/qareports.php`, formDetails, {
					headers: {
						"Content-Type": "multipart/form-data",
					},
				})
				.then((response) => {
          if(response.data === "No data Available"){
            alert(response.data);
          }else{
            setData(response.data);
          }
            
				})
				.catch((error) => {
					console.error("Error fetching data:", error);
				});
        // eslint-disable-next-line react-hooks/exhaustive-deps
  },[]);

  return (
    <div className={ReportCSS["rep-body"]}>
      
      <div  className={ReportCSS["container"]}>
        <div className={ReportCSS["report-section"]}>
          <h1>Course Mean Report</h1>
          <table className={ReportCSS["report-table"]}>
            <thead>
              <tr>
                <th className={ReportCSS["report-th"]}>Exam</th>
                <th className={ReportCSS["report-th"]}>
                  Total Number of Students
                </th>
                <th className={ReportCSS["report-th"]}>
                  Total Students Attended the Exam
                </th>
                <th className={ReportCSS["report-th"]}>Feedback</th>
              </tr>
            </thead>
            <tbody>
            {data.map((exam, index) => (
								<tr key={index}>
									 <td className={ReportCSS["report-td"]}>{exam.title}</td>
                <td className={ReportCSS["report-td"]}>{exam.total_students}</td>
                <td className={ReportCSS["report-td"]}>{exam.attended_students}</td>
                <td className={ReportCSS["report-td"]}>
                  <Link to="/message">
                    <button>Feedback</button>{" "}
                  </Link>
                </td>
              </tr>
							))}
             
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default QA_REPORT;
