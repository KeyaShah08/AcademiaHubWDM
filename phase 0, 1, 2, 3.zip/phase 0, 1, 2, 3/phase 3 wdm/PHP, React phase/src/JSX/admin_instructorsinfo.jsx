import React from "react";
import infoCSS from "../CSS/admin_instructorsinfo.module.css";
import { Link } from 'react-router-dom'; // Make sure to adjust the import path if necessary

const InstructorInfo = () => {
  return (
    <div className={infoCSS["info-body"]}>
      <div className={infoCSS["navbar"]}>
        <span className={infoCSS["navbar-title"]}>
          Welcome to the Instructor's Information Page
        </span>
        <Link to="/admin_admin">Dashboard</Link>
      </div>
      <br />
      <br />

      <main>
        <section>
          <h2 className={infoCSS["info-h2"]}>Instructor's Details</h2>
          <table className={infoCSS["instinfotable"]}>
            <thead>
              <tr>
                <th className={infoCSS["instinfotable-th"]}>Name</th>
                <th className={infoCSS["instinfotable-th"]}>Email</th>
                <th className={infoCSS["instinfotable-th"]}>User ID</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className={infoCSS["instinfotable-td"]}>
                  <Link to="/admin_instructor1"
                    title="Total credits: 39, Completed Credit: 21, GPA: 3.78">Orren Johnson
                  </Link>
                </td>
                <td className={infoCSS["instinfotable-td"]}>
                  OrrenJohnson@example.com
                </td>
                <td className={infoCSS["instinfotable-td"]}>12345</td>
              </tr>
              <tr>
                <td className={infoCSS["instinfotable-td"]}>
                  <Link to="/admin_instructor2"
                    title="Total credits: 45, Completed Credit: 33, GPA: 3.3"
                  >
                    Luis Evans
                  </Link>
                </td>
                <td className={infoCSS["instinfotable-td"]}>
                  Luis Evans@example.com
                </td>
                <td className={infoCSS["instinfotable-td"]}>54321</td>
              </tr>
            </tbody>
          </table>
        </section>
      </main>
    </div>
  );
};

export default InstructorInfo;
