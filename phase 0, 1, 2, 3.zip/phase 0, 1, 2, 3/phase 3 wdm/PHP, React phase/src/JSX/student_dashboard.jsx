import React, { useState,useEffect } from "react";
import courseCSS from "../CSS/student_courses.module.css";
import { Link } from "react-router-dom";
import axios from "axios";
import Url from "../BackendURL";
import { Session } from "../UserContext";


const StudentDashboard = () => {
  const [search, setSearch] = useState("");
  const { userObject } = Session();
  const [data, setData] = useState([]);
  const [courseAvail, setCourses] = useState(false);

  useEffect(() => {
    function getMessages(){
      const formDetails = new FormData();
      formDetails.append('userId', userObject?.user_id);
      axios.post(`${Url}api/getallCourseForStudent.php`,formDetails,{
        headers: {
          'Content-Type': 'multipart/form-data', // Set the content type to multipart form data
        },
      })
        .then((response) => {
          if(response.data === "No course Available"){
            setCourses(false);
          }else{
            setCourses(true);
          setData(response.data);
          }
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    }
    // Make the HTTP request to the PHP file
    // eslint-disable-next-line react-hooks/exhaustive-deps
    if(userObject){

      getMessages();
    }
  }, [userObject]);

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };

  const filteredCourses = data.filter((course) =>
    course.courseName.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className={courseCSS["courses-body"]}>
      <div style={{ marginBottom: "20px" }}>
        <input
          type="text"
          placeholder="Search for a course..."
          value={search}
          onChange={handleSearchChange}
          style={{
            width: "100%",
            padding: "10px",
            fontSize: "16px",
            border: "2px solid #212b5f",
          }}
        />
      </div>
      
      <div style={{display:'flex', flexDirection: 'row'}}>
      { (courseAvail) ?
      (filteredCourses.map((course, index) => (
        <div key={index} className={courseCSS["tile"]}>
          <h2>{course.courseName}</h2>
          <div className={courseCSS["dropdown"]}>
            <button className={courseCSS["dropbtn"]}>Go to Content</button>
            <div className={courseCSS["dropdown-content"]}>
              <Link to={`/student_coursematerial/${course.courseId}`}>Course Material</Link>
              <Link to="/syllabus.pdf" target="_blank">Syllabus</Link>
              <Link to={`/student_examschedule/${course.courseId}`}>Exams/Assessments</Link>
              <Link to={`/student_feedback/${course.courseId}`}>Give Feedback</Link>
              <Link to={`/student_performance/${course.courseId}`}>Grades</Link>
            </div>
          </div>
        </div>
      ))) : 
      <div>
          <span>No Courses Available ... </span>
      </div> }
      </div>
    </div>
  );
};

export default StudentDashboard;
