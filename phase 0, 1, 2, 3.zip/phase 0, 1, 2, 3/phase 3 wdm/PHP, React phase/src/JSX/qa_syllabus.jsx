import React, {useState, useEffect} from "react";
import syllabusCSS from "../CSS/qa_syllabus.module.css";
import { Link } from "react-router-dom";
import axios from "axios";
import Url from "../BackendURL";

function QA_SYLLABUS() {
  const [data, setData] = useState([]);
  useEffect(()=>{
    axios
    .get(`${Url}api/getallcourses.php`)
    .then((response) => {
      setData(response.data);
    })
    .catch((error) => {
      console.error("Error fetching data:", error);
    });
  },[]);
  return (
    <div className={syllabusCSS["syll-body"]}>
      
      <br />
      <br />
      <table
        className={syllabusCSS["qa-table"]}
        border="2"
        style={{ width: "50%" }}
      >
        <thead>
        <tr>
        <th className={syllabusCSS["qa-th"]}>Courses</th>
        <th className={syllabusCSS["qa-th"]}>Syllabus</th>
          
        </tr>
        </thead>
        <tbody>
        {data.map((course, index) => (
                <tr key={index}>
          <td className={syllabusCSS["qa-td"]}>{course.courseName}</td>
          <td className={syllabusCSS["qa-td"]}>
          <Link to="/syllabus.pdf" target="_blank">Download</Link>
          </td>
        </tr>
              ))}
        
        </tbody>
       
      </table>
    </div>
  );
}

export default QA_SYLLABUS;
