import React, { useState, useEffect } from "react";
import notificationsCSS from "../CSS/qa_notifications.module.css";
import axios from "axios";
import Url from "../BackendURL";
import { Session } from "../UserContext";

const QA_Notifications = () => {

  const { userObject } = Session();
  const [data, setData] = useState([]);
  const [messageavail, setMessage] = useState(false); 

  useEffect(() => {
    function getMessages(){
      const formDetails = new FormData();
      formDetails.append('to', userObject?.user_id);
      axios.post(`${Url}api/getNotification.php`,formDetails,{
        headers: {
          'Content-Type': 'multipart/form-data', // Set the content type to multipart form data
        },
      })
        .then((response) => {
          if(response.data === "No meesage"){
            setMessage(false);
          }else{
          setMessage(true);
          console.log(response.data);
          setData(response.data);
          }
        })
        .catch((error) => {
          console.error("Error fetching data:", error);
        });
    }
    // Make the HTTP request to the PHP file
    // eslint-disable-next-line react-hooks/exhaustive-deps
    if(userObject){

      getMessages();
    }
  }, [userObject]);

  return (
    <div>
     
      <div className={notificationsCSS["notifications-container"]}>
        <main>
         {(messageavail) ? (
            data.map((message,index) => (
              <section key={index} className={notificationsCSS["notification"]}>
              <div className={notificationsCSS["notification-info"]}>
                <h2>{message.senderName}</h2>
                <p>{message.messageDesc}</p>
              </div>
            </section>
            ))
         ) : 
              <span> No Messages ...</span>
          }
        </main>
      </div>
    </div>
  );
};

export default QA_Notifications;
