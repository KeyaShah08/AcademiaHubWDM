import React, { useEffect, useState } from "react";
import gradeCSS from "../CSS/instructor_grade_exam.module.css";
// import { Link } from 'react-router-dom'; // Make sure to adjust the import path if necessary
import { useParams } from "react-router-dom";
import axios from "axios";
import Url from "../BackendURL";

const ExamResults = () => {
	const { examid } = useParams();
	const [data, setData] = useState([]);

	useEffect(() => {
		function getData() {
			const formDetails = new FormData();
			formDetails.append("exam_id", examid);
			axios
				.post(`${Url}api/examresult.php`, formDetails, {
					headers: {
						"Content-Type": "multipart/form-data",
					},
				})
				.then((response) => {
					setData(response.data);
				})
				.catch((error) => {
					console.error("Error fetching data:", error);
				});
		}
		// Make the HTTP request to the PHP file
		getData();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	return (
		<div className={gradeCSS["grade-body"]}>
			<h1 className={gradeCSS["grade-h1"]}>Grade Exam</h1>
			<table className={gradeCSS["grade-table"]}>
				<thead>
					<tr>
						<th className={gradeCSS["grade-th"]}>Student Name</th>
						<th className={gradeCSS["grade-th"]}>Email</th>
						<th className={gradeCSS["grade-th"]}>Score</th>
					</tr>
				</thead>
				<tbody>
					{data.map((grade, index) => (
						<tr key={index}>
							<td className={gradeCSS["grade-td"]}>{grade.name}</td>
							<td className={gradeCSS["grade-td"]}>{grade.email}</td>
							<td className={gradeCSS["grade-td"]}>
								<button className={gradeCSS["grade-button"]}>{parseInt(grade.score)} / {grade.total}</button>
							</td>
						</tr>
					))}
				</tbody>
			</table>
		</div>
	);
};

export default ExamResults;
