import React, {useState} from "react";
import contactusCSS from "../CSS/admin_contactus.module.css";
import Url from "../BackendURL";
import axios from "axios";

const ContactUs = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  // Event handler for form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Event handler for form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    const formDetails = new FormData();
    formDetails.append("name", formData.name);
    formDetails.append("email", formData.email);
    formDetails.append("message", formData.message);
    await axios
				.post(`${Url}api/postcontact.php`, formDetails, {
					headers: {
						"Content-Type": "multipart/form-data",
					},
				})
				.then((response) => {
          // console.log(response.data);
					alert("Message Sent");
          setFormData({ name: '', email: '', message: '' });
				})
				.catch((error) => {
					console.error("Error fetching data:", error);
				});
  };
  return (
    <div className={contactusCSS["contactus-body"]}>
      <header className={contactusCSS["contactus-header"]}>
        <h1 className={`${contactusCSS["contactus-h1"]}`}>Contact Us</h1>
        <p>Get in touch with us. We'd love to hear from you!</p>
      </header>
      <div className={contactusCSS["contactus-container"]}>
        <div>
          
        <form
            action="#"
            method="post"
            className={contactusCSS["contact-form"]}
            onSubmit={handleSubmit} // Attach the submit handler
          >
            <h2 className={`${contactusCSS["contactus-h2"]}`}>Contact Form</h2>
            <label htmlFor="name">Name:</label>
            <input
              className={contactusCSS["contact-inputField"]}
              type="text"
              id="name"
              name="name"
              value={formData.name} // Bind input value to state
              onChange={handleInputChange} // Attach the change handler
              required
            />

            <label htmlFor="email">Email:</label>
            <input
              className={contactusCSS["contact-inputField"]}
              type="email"
              id="email"
              name="email"
              value={formData.email} // Bind input value to state
              onChange={handleInputChange} // Attach the change handler
              required
            />

            <label htmlFor="message">Message:</label>
            <textarea
              className={contactusCSS["contact-inputField"]}
              id="message"
              name="message"
              rows="4"
              value={formData.message} // Bind textarea value to state
              onChange={handleInputChange} // Attach the change handler
              required
            ></textarea>

            <button className={contactusCSS["contactus-button"]}>Submit</button>
            <br />
            <br />
          </form>

        </div>
        
      </div>
    </div>
  );
};

export default ContactUs;
