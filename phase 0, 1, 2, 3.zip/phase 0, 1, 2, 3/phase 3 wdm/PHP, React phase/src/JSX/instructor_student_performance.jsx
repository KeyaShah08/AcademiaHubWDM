import React, {useState, useEffect} from "react";
import performanceCSS from "../CSS/instructor_student_performance.module.css";
import { Link } from 'react-router-dom';
import { useParams } from "react-router-dom";
import axios from "axios";
import Url from "../BackendURL";

const Std_Performance = () => {

  const { courseId } = useParams();
  const [data, setData] = useState([]);

  useEffect(() => {
		function getData() {
			const formDetails = new FormData();
			formDetails.append("course_id", courseId);
			axios
				.post(`${Url}api/allstudentsgrade.php`, formDetails, {
					headers: {
						"Content-Type": "multipart/form-data",
					},
				})
				.then((response) => {
					setData(response.data);
				})
				.catch((error) => {
					console.error("Error fetching data:", error);
				});
		}
		// Make the HTTP request to the PHP file
		getData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

  return (
    <div className={`${performanceCSS["perf-body"]}`}>
      <div className={`${performanceCSS["dashboard"]}`}>
        <div className={`${performanceCSS["report"]}`}>
          <h2 className={`${performanceCSS["performance-h2"]}`}>
            Student Performance Report
          </h2>
          <table className={`${performanceCSS["performance-table"]}`}>
            <thead>
              <tr>
                <th className={`${performanceCSS["performance-th"]}`}>Student Name</th>
                <th className={`${performanceCSS["performance-th"]}`}>Student Email</th>
                <th className={`${performanceCSS["performance-th"]}`}>Grade</th>
                <th className={`${performanceCSS["performance-th"]}`}>Feedback</th>
              </tr>
            </thead>
            <tbody>
              {data.map((student, index) => (
                <tr key={index}>
                  <td className={`${performanceCSS["performance-td"]}`}>{student.name}</td>
                  <td className={`${performanceCSS["performance-td"]}`}>{student.email}</td>
                  <td className={`${performanceCSS["performance-td"]}`}>{((student.score / student.total) * 100).toFixed(2)}%</td>
                  <td className={`${performanceCSS["performance-td"]}`}>
                    <Link to={"/message"} className={`${performanceCSS["feedback-button"]}`}>Give Feedback</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Std_Performance;
