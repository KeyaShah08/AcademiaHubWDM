import React from 'react';
import AppRoutes from '../src/Routes';
import { SessionProvider } from "./UserContext";

const App = () => {
  return (
  <SessionProvider>
    <AppRoutes/>
  </SessionProvider>
  );
};
export default App;