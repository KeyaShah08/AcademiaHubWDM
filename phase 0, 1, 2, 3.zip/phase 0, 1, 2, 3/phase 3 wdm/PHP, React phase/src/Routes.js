import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Dashboard from "./JSX/pg_dashboard.jsx";
import Homepage from "./JSX/admin_homepage.jsx";
import AdminAboutUs from "./JSX/admin_aboutus.jsx";
import AdminServices from "./JSX/admin_services.jsx";
import UniversityLogin from "./JSX/admin_login.jsx";
import ContactUs from "./JSX/admin_contactus.jsx";
import StudentConcerns from "./JSX/pg_studentconcerns.jsx";
import PerformanceDashboard from "./JSX/pg_performance.jsx";
import ChatPage from "./JSX/pg_chat.jsx";
import QAProfilePage from "./JSX/qa_profile.jsx";
import QAReport from "./JSX/qa_report.jsx";
import Notifications from "./JSX/notifications.jsx";
import QADashboard from "./JSX/qa_dashboard.jsx";
import Message from "./JSX/message.jsx";
import QACourses from "./JSX/qa_courses.jsx";
import QAPolicies from "./JSX/qa_policies.jsx";
import QAChatPage from "./JSX/qa_chat.jsx";
import QASyllabus from "./JSX/qa_syllabus.jsx";

import ForgetPassword from "./JSX/admin_forgetpassword.jsx";
import UniversitySignUp from "./JSX/admin_signup.jsx";
import StudentDashboard from "./JSX/student_dashboard.jsx";
import StdCourses from "./JSX/student_courses.jsx";
import StudentFeedback from "./JSX/student_feedback.jsx";
import StudentExamSchedule from "./JSX/student_examschedule.jsx";
import StudentCourseMaterial from "./JSX/student_coursematerial.jsx";
import StudentSearchCourse from "./JSX/student_course_search.jsx";
import StudentExam from "./JSX/studentTakeExam.jsx";

import AdminPage from "./JSX/admin_admin.jsx";
import StudentInfo from "./JSX/admin_studentsinfo.jsx";
import UserProfile from "./JSX/admin_userprofile.jsx";
import ActivityPage from "./JSX/admin_monitor.jsx";

import InstructorDashboard from "./JSX/instructor_dashboard.jsx";
import StdPerformance from "./JSX/instructor_student_performance.jsx";
import InstructorFeedback from "./JSX/instructor_feedback.jsx";
import InstructorAnnouncement from "./JSX/instructor_announcement.jsx";
import InstructorCreateExam from "./JSX/instructor_create_exam.jsx";
import InstructorCourseObjective from "./JSX/instructor_course_objective.jsx";
import InstructorGradeExam from "./JSX/instructor_grade_exam.jsx";
import Navbar from "./JSX/Navbar.jsx";
import { Session } from "./UserContext.js";
import VerifyOtp from "./JSX/verifyOtp.jsx";
import ExamResults from "./JSX/examresults.jsx";
import ChangePass from "./JSX/changepass.jsx";
import StudentPerformance from "./JSX/student_performance.jsx";
const AppRoutes = () => {
	const { userObject, isLoading } = Session();
	console.log(userObject);

	if (isLoading) {
		return "Loading...";
	}
	return (
		<Router>
			<Navbar />
			<Routes>
				<Route path="/" element={<Homepage />} />
				<Route path="/aboutus" element={<AdminAboutUs />} />
				<Route path="/services" element={<AdminServices />} />
				<Route path="/contactus" element={<ContactUs />} />
				<Route path="/changepass/:id" element={<ChangePass/>}/>
				<Route path="/forgetpassword" element={!userObject ? <ForgetPassword /> : <Navigate to="/" replace />} />
				<Route path="/signup" element={!userObject ? <UniversitySignUp /> : <Navigate to="/" replace />} />
				<Route path="/login" element={!userObject ? <UniversityLogin /> : <Navigate to="/" replace />}/>
				<Route path="/verify" element={userObject?.verified === false ? <VerifyOtp /> : <Navigate to="/" replace />} />

				<Route path="/student_dashboard" element={userObject?.verified && userObject?.role === "student" ? <StudentDashboard /> : <Navigate to="/login" replace />} />
				<Route path="/student_courses" element={userObject?.role === "student" ? <StdCourses /> : <Navigate to="/login" replace />} />
				<Route path="/student_performance/:courseid" element={userObject?.role === "student" ? <StudentPerformance /> : <Navigate to="/login" replace />} />
				<Route path="/student_feedback/:courseId" element={userObject?.role === "student" ? <StudentFeedback /> : <Navigate to="/login" replace />} />
				<Route path="/student_examschedule/:courseId" element={userObject?.role === "student" ? <StudentExamSchedule /> : <Navigate to="/login" replace />} />
				<Route path="/student_coursematerial/:courseId" element={userObject?.role === "student" ? <StudentCourseMaterial /> : <Navigate to="/login" replace />} />
				<Route path="/student_course_search" element={userObject?.role === "student" ? <StudentSearchCourse /> : <Navigate to="/login" replace />} />
				<Route path = "/studentTakeExam/:examId/:courseId/" element={userObject?.role === "student" ? <StudentExam /> : <Navigate to="/login" replace />} />

				<Route path="/instructor_dashboard" element={userObject?.verified && userObject?.role === "instructor" ? <InstructorDashboard /> : <Navigate to="/login" replace />} />
				<Route path="/instructor_student_performance/:courseId" element={userObject?.role === "instructor" ? <StdPerformance /> : <Navigate to="/login" replace />} />
				<Route path="/instructor_feedback" element={userObject?.role === "instructor" ? <InstructorFeedback /> : <Navigate to="/login" replace />} />
				<Route path="/instructor_announcement" element={userObject?.role === "instructor" ? <InstructorAnnouncement /> : <Navigate to="/login" replace />} />
				<Route path="/instructor_create_exam/:courseid" element={userObject?.role === "instructor" ? <InstructorCreateExam /> : <Navigate to="/login" replace />} />
				<Route path="/instructor_course_objective/:courseId" element={userObject?.role === "instructor" ? <InstructorCourseObjective /> : <Navigate to="/login" replace />} />
				<Route path="/instructor_grade_exam/:courseId" element={userObject?.role === "instructor" ? <InstructorGradeExam /> : <Navigate to="/login" replace />} />
				<Route path="/instructor_examresult/:examid" element={userObject?.role === "instructor" ? <ExamResults /> : <Navigate to="/login" replace />} />

				<Route path="/pg_dashboard" element={userObject?.verified && userObject?.role === "pc" ? <Dashboard /> : <Navigate to="/login" replace />} />
				<Route path="/pg_studentconcern" element={userObject?.verified && userObject?.role === "pc" ? <StudentConcerns /> : <Navigate to="/login" replace />} />
				<Route path="/pg_performance" element={userObject?.verified && userObject?.role === "pc" ? <PerformanceDashboard /> : <Navigate to="/login" replace />} />
				<Route path="/pg_chat" element={userObject?.verified && userObject?.role === "pc" ? <ChatPage /> : <Navigate to="/login" replace />} />
				<Route path="/profile" element={<QAProfilePage />} />
				<Route path="/pc_report/:courseid" element={userObject?.verified && userObject?.role === "pc" ? <QAReport /> : <Navigate to="/login" replace />} />
				<Route path="/pc_courses" element={userObject?.verified && userObject?.role === "pc" ? <QACourses /> : <Navigate to="/login" replace />} />

				<Route path="/qa_report/:courseid" element={userObject?.verified && userObject?.role === "qa" ? <QAReport /> : <Navigate to="/login" replace />} />
				<Route path="/notifications" element={<Notifications />} />
				<Route path="/qa_dashboard" element={userObject?.verified && userObject?.role === "qa" ? <QADashboard /> : <Navigate to="/login" replace />} />
				<Route path="/message" element={<Message />} />
				<Route path="/qa_courses" element={userObject?.verified && userObject?.role === "qa" ? <QACourses /> : <Navigate to="/login" replace />} />
				<Route path="/qa_policies" element={userObject?.verified && userObject?.role === "qa" ? <QAPolicies /> : <Navigate to="/login" replace />} />
				<Route path="/qa_chat" element={userObject?.verified && userObject?.role === "qa" ? <QAChatPage /> : <Navigate to="/login" replace />} />
				<Route path="/qa_syllabus" element={userObject?.verified && userObject?.role === "qa" ? <QASyllabus /> : <Navigate to="/login" replace />} />

				<Route path="/admin_admin" element={userObject?.verified && userObject?.role === "admin" ? <AdminPage /> : <Navigate to="/login" replace />} />
				<Route path="/admin_profiles/:role" element={userObject?.role === "admin" ? <StudentInfo /> : <Navigate to="/login" replace />} />
				<Route path="/admin_userprofile/:role/:email/:name" element={userObject?.role === "admin" ? <UserProfile /> : <Navigate to="/login" replace />} />
				<Route path="/admin_monitor" element={userObject?.role === "admin" ? <ActivityPage /> : <Navigate to="/login" replace />} />
				
			</Routes>
		</Router>
	);
};

export default AppRoutes;
