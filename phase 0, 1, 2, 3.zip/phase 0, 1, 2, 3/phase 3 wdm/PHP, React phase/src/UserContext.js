import React, { useState, createContext, useContext, useEffect } from "react";

const UserContext = createContext();

export const SessionProvider = ({ children }) => {
	const [userObject, setUserObject] = useState(null);
	const [isLoading, setIsLoading] = useState(true);


	const login = (userData) => {
		setUserObject(userData);
	};

	const logout = () => {
		setUserObject(null);
		localStorage.removeItem("userObject");
	};

	useEffect(() => {
		const storedUser = localStorage.getItem("userObject");
		if (storedUser) {
			setUserObject(JSON.parse(storedUser));
		}
		setIsLoading(false);
	}, []);

	// Update localStorage or cookies when user data changes
	useEffect(() => {
		if (userObject) {
			localStorage.setItem("userObject", JSON.stringify(userObject));
		} else {
			localStorage.removeItem("userOject");
		}
	}, [userObject]);

	return <UserContext.Provider value={{ userObject, login, logout, isLoading }}>{children}</UserContext.Provider>;
};

export const Session = () => {
	return useContext(UserContext);
};
