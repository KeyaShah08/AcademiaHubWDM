 const Url = 'http://localhost/Keya/';
//const Url = 'http://sxk2005.uta.cloud/';

export default Url;