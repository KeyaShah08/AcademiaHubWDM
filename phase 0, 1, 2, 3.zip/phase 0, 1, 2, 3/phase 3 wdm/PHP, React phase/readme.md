Group 12: 

• Keya Kalpeshbhai Shah - 1002079489
• Sahithi Velaga - 1002033633
• Sreeja Reddy Kakularapu - 1002072005
• Tejaswini Seeram - 1002069243
• Thirumala Gopi Lakshmisetty - 1002170548 

UTA cloud link: http://sxk2005.uta.cloud/

Steps for run this file:

(1) Install Xampp on your PC.
(2) Start Apache and MySQL on Xampp server.
(3) Open Admin form Xampp and it will redirect to http://localhost/phpmyadmin
(4) Create new database name " keya " and copy-paste create table SQL query from createTable.sql -> It   will create all the tables in the database.
(5) Open the Xampp folder in C drive on your PC and make a new folde name " Keya " in " htdocs " folder.
(6) Copy - paste all the files from zip in that folder.
(7) Open " Keya " folder from Visual Studio.
(8) Open the terminal and write the command " npm i ".
(9) Run " npm start " in terminal and it will redirect to the website on localhost.

Please note that email varification will not be working while running the website on localhost as the code and website is already deployed on UTA cloud so it will work on Cloud Console. So take the OTP from database while qorking on localhost.

Paste the dummy data from dummydata.sql as per necessary. (for example: paste the instructor's course details after creating new user role name: Instructor )