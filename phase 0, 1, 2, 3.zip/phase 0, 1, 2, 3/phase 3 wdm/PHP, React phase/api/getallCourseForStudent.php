<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');

require 'vendor/autoload.php';

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$userId = mysqli_real_escape_string($connection, $_POST['userId']);

$firstQuery = "SELECT * FROM course_enrollment WHERE user_id = '$userId'";
$res = mysqli_query($connection, $firstQuery);

if($res && mysqli_num_rows($res) != 0){
    $courses = array();
    while($row = mysqli_fetch_assoc($res)){
        $courseId = $row['course_id'];
        $query = "SELECT * FROM courses WHERE course_id = '$courseId'";
        $result = mysqli_query($connection, $query);
        $lowerrow = mysqli_fetch_assoc($result);
        $course = array(
            "courseName" => $lowerrow['name'],
            "courseId" => $lowerrow['course_id'],
        );

        $courses[] = $course;
    }
    echo json_encode($courses);
}else{
    echo "No course Available";
}

