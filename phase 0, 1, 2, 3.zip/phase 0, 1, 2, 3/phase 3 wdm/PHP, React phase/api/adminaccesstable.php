<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET');

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}



$query = "SELECT ce.enrollment_id AS eid,  u.email AS email, c.name AS course_name
FROM course_enrollment ce
JOIN users u ON ce.user_id = u.user_id
JOIN courses c ON ce.course_id = c.course_id;
";
$res = mysqli_query($connection, $query);

if($res){
    $enrollments = array();
     while($row = mysqli_fetch_assoc($res)){
        $enrollment = array(
            "email" => $row['email'],
            "courseName" => $row['course_name'],
            "eid" => $row['eid'],
        );

        $enrollments[] = $enrollment;
     }
     echo json_encode($enrollments);
}


?>