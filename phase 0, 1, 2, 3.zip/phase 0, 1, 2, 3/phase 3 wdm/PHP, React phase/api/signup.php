<?php
header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}


$email = mysqli_real_escape_string($connection, $_POST['email']);
$password = password_hash($_POST['password'], PASSWORD_BCRYPT);
$name = mysqli_real_escape_string($connection, $_POST['name']);
$role = mysqli_real_escape_string($connection, $_POST['role']);


$query = "SELECT * FROM users WHERE email = '$email'";
$res = mysqli_query($connection, $query);

if (!$res || mysqli_num_rows($res) == 0) {
    $mail = new PHPMailer(true);
 
        try {
            $mail->SMTPDebug = 0;//SMTP::DEBUG_SERVER;
            $mail->isSMTP();
            $mail->Host = MAIL_HOST;
            $mail->SMTPAuth = true;
            $mail->Username = MAIL_USER;
            $mail->Password = MAIL_PASS;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            $mail->setFrom(MAIL_USER, 'AcademiaHub');
            $mail->addAddress($email, $name);
            $mail->isHTML(true);
            $verification_code = substr(number_format(time() * rand(), 0, '', ''), 0, 6);
            $mail->Subject = 'Email verification';
            $mail->Body    = '<p>Your verification code is: <b style="font-size: 30px;">' . $verification_code . '</b></p>';
            $mail->send(); 
            $query = "INSERT INTO users (role, name, email, password, code, verified) 
            VALUES ('$role', '$name', '$email', '$password', '" . $verification_code . "', False)";
            if (mysqli_query($connection, $query)) {
                $response = array(
                    'role' => $role,
                    'name' => $name,
                    'email' => $email,
                    'code' => $verification_code,
                    'verified' => false 
                );
                echo json_encode($response);
            } else {
                echo("Registration Failed");
            } 
           
 
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }

} else {
    echo('User already registered');
}
?>