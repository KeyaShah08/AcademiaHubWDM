<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');


require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}


$message = mysqli_real_escape_string($connection, $_POST['message']);
$email = mysqli_real_escape_string($connection, $_POST['email']);
$name = mysqli_real_escape_string($connection, $_POST['name']);
echo $email;

$query = "INSERT INTO contact (email, message, name, resolved) VALUES
('$email', '$message', '$name', 0);";

if (mysqli_query($connection, $query)) {
    echo "Contact Message Sent";
} else {
    echo "Error updating contact: " . mysqli_error($connection);
}
mysqli_close($connection);
?>
