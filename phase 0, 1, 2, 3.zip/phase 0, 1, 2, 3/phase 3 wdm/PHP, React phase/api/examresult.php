<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');


require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}


$exam_id = mysqli_real_escape_string($connection, $_POST['exam_id']);

$query = "SELECT g.score AS score, u.name AS name, u.email AS email, e.total AS total
FROM grades AS g
JOIN users AS u ON g.user_id = u.user_id
JOIN exam AS e ON g.exam_id = e.exam_id
WHERE g.exam_id = '$exam_id';
";

$res = mysqli_query($connection, $query);

if($res){
    $grades = array();
     while($row = mysqli_fetch_assoc($res)){
        $grade = array(
            "score" => $row['score'],
            "name" => $row['name'],
            "email" => $row['email'],
            "total" => $row['total'],
        );

        $grades[] = $grade;
     }
     echo json_encode($grades);
}

