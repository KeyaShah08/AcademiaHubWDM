<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');


require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}


$course_id = mysqli_real_escape_string($connection, $_POST['course_id']);

$query = "SELECT * FROM exam WHERE course_id = '$course_id'";

$res = mysqli_query($connection, $query);

if($res){
    $exams = array();
     while($row = mysqli_fetch_assoc($res)){
        $exam = array(
            "title" => $row['title'],
            "date" => $row['date'],
            "exam_id" => $row['exam_id'],
        );

        $exams[] = $exam;
     }
     echo json_encode($exams);
}

