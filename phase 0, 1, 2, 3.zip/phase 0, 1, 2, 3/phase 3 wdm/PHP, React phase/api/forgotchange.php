<?php
header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Assuming you have received the updated data in the POST request
$pass = mysqli_real_escape_string($connection, $_POST['pass']);
$id = mysqli_real_escape_string($connection, $_POST['id']);

$newPasswordHash = password_hash($pass, PASSWORD_BCRYPT);

$updateQuery = "UPDATE users SET password = '$newPasswordHash' WHERE user_id = '$id'";
$updateResult = mysqli_query($connection, $updateQuery);

if ($updateResult) {
    echo "Password Changed Successfully"; // Password updated successfully
} else {
    echo "Password update failed";
}


mysqli_close($connection);
?>
