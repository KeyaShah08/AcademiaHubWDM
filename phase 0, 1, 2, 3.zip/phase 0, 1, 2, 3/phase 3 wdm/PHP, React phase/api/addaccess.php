<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$course_id = mysqli_real_escape_string($connection, $_POST['course_id']);
$email = mysqli_real_escape_string($connection, $_POST['email']);


$rowQuery = "SELECT * FROM users WHERE email = '$email'";
$res = mysqli_query($connection, $rowQuery);

if($res && mysqli_num_rows($res) > 0){
    $row = mysqli_fetch_assoc($res);

$user_id = $row['user_id'];


$query = "INSERT INTO course_enrollment (course_id, user_id) 
VALUES ('$course_id', '$user_id')";

if (mysqli_query($connection, $query)) {
    echo ("Access Granted");
}
else{
    echo('User not registered');
}
}else{
    echo "User Not Found";

 
}
?>
