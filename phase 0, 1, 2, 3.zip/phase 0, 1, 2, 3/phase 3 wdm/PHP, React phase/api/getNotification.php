<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');

require 'vendor/autoload.php';

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$toId = mysqli_real_escape_string($connection, $_POST['to']);

$firstQuery = "SELECT * FROM message WHERE to_user_id = '$toId'";
$res = mysqli_query($connection, $firstQuery);

if($res && mysqli_num_rows($res) != 0){
    $messages = array();
    while($row = mysqli_fetch_assoc($res)){
        $userId = $row['from_user_id'];
        $query = "SELECT * FROM users WHERE user_id = '$userId'";
        $result = mysqli_query($connection, $query);
        $lowerrow = mysqli_fetch_assoc($result);
        $message = array(
            "senderName" => $lowerrow['name'],
            "messageDesc" => $row['messageDesc'],
        );

        $messages[] = $message;
    }
    echo json_encode($messages);
}else{
    echo "No meesage";
}

mysqli_close($connection);
?>
