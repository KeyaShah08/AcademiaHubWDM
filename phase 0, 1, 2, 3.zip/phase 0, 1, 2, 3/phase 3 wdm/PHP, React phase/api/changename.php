<?php
header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Assuming you have received the updated data in the POST request
$name = mysqli_real_escape_string($connection, $_POST['name']);
$email = mysqli_real_escape_string($connection, $_POST['email']);



// If the email exists, update the user's information
$updateQuery = "UPDATE users SET name = '$name' WHERE email = '$email'";

if (mysqli_query($connection, $updateQuery)) {
    $updatedUserInfo = mysqli_query($connection, "SELECT * FROM users WHERE email = '$email'");
    $user = mysqli_fetch_assoc($updatedUserInfo);
    echo json_encode($user);
} else {
    echo "Failed to update user information";
}

mysqli_close($connection);
?>
