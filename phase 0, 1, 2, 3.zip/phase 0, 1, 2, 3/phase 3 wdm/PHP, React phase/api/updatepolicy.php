<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET');


require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}
$id = $_POST['id'];
$desc = $_POST['desc'];
$title = $_POST['title'];


$query = "UPDATE policies
SET title = '$title', description = '$desc'
WHERE policy_id =$id;
";

$res = mysqli_query($connection, $query);

if($res){
    echo ("Policy Updated");
}
else{
    echo("Update Failed");
}

mysqli_close($connection);
?>
