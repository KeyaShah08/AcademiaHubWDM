<?php
header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');
require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}


$email = mysqli_real_escape_string($connection, $_POST['email']);
$password =$_POST['password'];

$query = "SELECT * FROM users WHERE email = '$email'";
$res = mysqli_query($connection, $query);

if ($res && mysqli_num_rows($res) > 0) {
    $row = mysqli_fetch_assoc($res);
    if (password_verify($password, $row['password'])) {
        $role = $row['role'];
        $login = date('Y-m-d H:i:s');
        $sql = "INSERT INTO monitor (email, role, login) VALUES ('$email', '$role', '$login')";
        $result = mysqli_query($connection, $sql);
        echo json_encode($row);
    } else {
        echo "Wrong password";
    }
} else {
    echo "Invalid Email";
}


mysqli_close($connection);
?>
