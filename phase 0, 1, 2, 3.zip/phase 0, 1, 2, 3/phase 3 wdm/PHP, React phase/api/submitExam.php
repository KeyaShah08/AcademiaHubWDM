<?php
header('Access-Control-Allow-Origin: http://localhost:3000'); // Replace with your frontend URL
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');
require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$exam_id = $_POST['exam_id'];
$user_id = $_POST['user_id'];
$course_id = $_POST['course_id'];
$score = $_POST['score'];


// $query = "SELECT * from exam where exam_id='$exam_id'";
// $result = mysqli_query($connection, $query);
// $row = mysqli_fetch_assoc($result);
// $total = $row['total'];

//$percentage = ($score / $total) * 100;

$sql = "INSERT INTO grades (exam_id, user_id, course_id, score) VALUES ('$exam_id', '$user_id', '$course_id', '$score')";
$res = mysqli_query($connection, $sql);

if ($res) {
    echo "Submission Successful";
} else {
    echo "Submission Failed";
}

mysqli_close($connection);
?>
