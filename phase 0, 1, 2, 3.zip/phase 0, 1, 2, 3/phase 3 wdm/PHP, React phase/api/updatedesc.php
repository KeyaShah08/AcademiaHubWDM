<?php
header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Assuming you have received the updated data in the POST request
$courseId = mysqli_real_escape_string($connection, $_POST['courseId']);
$desc = mysqli_real_escape_string($connection, $_POST['desc']);



// If the email exists, update the user's information
$updateQuery = "UPDATE courses SET description = '$desc' WHERE course_id = '$courseId'";

if (mysqli_query($connection, $updateQuery)) {

    echo "Course Description Updated";
} else {
    echo "Failed to update user information";
}

mysqli_close($connection);
?>
