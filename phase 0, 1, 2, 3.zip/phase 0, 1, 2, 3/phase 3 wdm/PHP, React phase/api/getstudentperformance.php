<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');


require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}


$user_id = mysqli_real_escape_string($connection, $_POST['id']);
$course_id = mysqli_real_escape_string($connection, $_POST['courseid']);

$query = "select e.exam_id, score, total, title from users u, exam e, grades g where u.user_id = g.user_id and g.exam_id = e.exam_id and u.user_id = '$user_id' and e.course_id = '$course_id'; 
";

$res = mysqli_query($connection, $query);

if($res){
    $grades = array();
     while($row = mysqli_fetch_assoc($res)){
        $grade = array(
            "score" => $row['score'],
            "title" => $row['title'],
            "total" => $row['total'],
        );

        $grades[] = $grade;
     }
     echo json_encode($grades);
}

