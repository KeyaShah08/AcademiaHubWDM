<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET');


require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}



$query = "SELECT
g.user_id,
u.name AS name,
SUM(g.score) AS total_score,
SUM(e.total) AS total_exam_total
FROM
grades g
JOIN
users u
ON
u.user_id = g.user_id
JOIN
exam e
ON
g.exam_id = e.exam_id
GROUP BY
g.user_id;

";

$res = mysqli_query($connection, $query);

if($res){
    $exams = array();
     while($row = mysqli_fetch_assoc($res)){
        $exam = array(
            "total_score" => $row['total_score'],
            "name" => $row['name'],
            "total_exam_total" => $row['total_exam_total'],
        );

        $exams[] = $exam;
     }
     echo json_encode($exams);
}
mysqli_close($connection);
?>
