<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');

require 'vendor/autoload.php';

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$fromId = mysqli_real_escape_string($connection, $_POST['from']);
$role = mysqli_real_escape_string($connection, $_POST['role']);
$email = mysqli_real_escape_string($connection, $_POST['email']);
$message = mysqli_real_escape_string($connection, $_POST['message']);

$rowQuery = "SELECT * FROM users WHERE email = '$email' and role='$role'";
$res = mysqli_query($connection, $rowQuery);

if(mysqli_num_rows($res) == 0){
    echo "User Not Found";
}else{

$row = mysqli_fetch_assoc($res);

$toId = $row['user_id'];
echo $toId;



$query = "INSERT INTO message (from_user_id, to_user_id, messageDesc) 
VALUES ('$fromId', '$toId', '$message')";

if (mysqli_query($connection, $query)) {
    $response = array(
        'from' => $fromId,
        'to' => $row['user_id'],
        'message' => $message,
    );
    echo json_encode($response);
} 
}
?>
