<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');

require 'vendor/autoload.php';

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}


$courseId = mysqli_real_escape_string($connection, $_POST['courseId']);

$query = "SELECT * FROM courses WHERE course_id = '$courseId'";

$res = mysqli_query($connection, $query);

if($res){
    $row = mysqli_fetch_assoc($res);
    $instructorId = $row['instructor_id'];
    $query = "SELECT * from users WHERE user_id = '$instructorId'";
    $result = mysqli_query($connection, $query);
    if($result){
        $fetchRow = mysqli_fetch_assoc($result);
        echo json_encode($fetchRow);
    }else{
        echo "Not found";
    }
}
mysqli_close($connection);
?>
