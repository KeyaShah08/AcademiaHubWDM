<?php
header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$link="http://sxk2005.uta.cloud";
$email = mysqli_real_escape_string($connection, $_POST['email']);


$query = "SELECT * FROM users WHERE email = '$email'";
$res = mysqli_query($connection, $query);

if ($res && mysqli_num_rows($res) > 0) {
    $mail = new PHPMailer(true);
    $row = mysqli_fetch_assoc($res);
    $id = $row['user_id'];
    $name = $row['name'];
        try {
            $mail->SMTPDebug = 0;//SMTP::DEBUG_SERVER;
            $mail->isSMTP();
            $mail->Host = MAIL_HOST;
            $mail->SMTPAuth = true;
            $mail->Username = MAIL_USER;
            $mail->Password = MAIL_PASS;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            $mail->setFrom(MAIL_USER, 'AcademiaHub');
            $mail->addAddress($email, $name);
            $mail->isHTML(true);
            $mail->Subject = 'Password Reset';
            $mail->Body    = "Your Reset Link is $link/changepass/$id";
            $mail->send(); 
            echo true;
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }

} else {
    echo('User not registered');
}
?>