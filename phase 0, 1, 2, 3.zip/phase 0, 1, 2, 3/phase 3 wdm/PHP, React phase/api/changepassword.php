<?php
header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Assuming you have received the updated data in the POST request
$old = mysqli_real_escape_string($connection, $_POST['old']);
$email = mysqli_real_escape_string($connection, $_POST['email']);
$new = mysqli_real_escape_string($connection, $_POST['new']);


$query = "SELECT password FROM users WHERE email = '$email'";
$result = mysqli_query($connection, $query);

$row = mysqli_fetch_assoc($result);
$hashedPassword = $row['password'];

if (password_verify($old, $hashedPassword)) {
    // Old password is correct, update to the new password
    $newPasswordHash = password_hash($new, PASSWORD_BCRYPT);

    $updateQuery = "UPDATE users SET password = '$newPasswordHash' WHERE email = '$email'";
    $updateResult = mysqli_query($connection, $updateQuery);

    if ($updateResult) {
        echo "Password Changed Successfully"; // Password updated successfully
    } else {
        echo "Password update failed";
    }
} else {
    echo "Incorrect old password";
}

mysqli_close($connection);
?>
