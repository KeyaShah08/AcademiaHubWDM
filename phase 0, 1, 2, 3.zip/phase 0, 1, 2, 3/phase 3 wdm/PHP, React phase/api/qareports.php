<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');


require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}


$course_id = mysqli_real_escape_string($connection, $_POST['course_id']);


$query = "SELECT g.exam_id, total_students, attended_students, g.title
FROM (
    SELECT course_id, COUNT(*) as total_students
    FROM course_enrollment
    WHERE course_id = '$course_id'
    GROUP BY course_id
) ce
JOIN (
    SELECT grades.exam_id, grades.course_id, COUNT(*) as attended_students, exam.title as title 
    FROM grades
    JOIN exam ON exam.exam_id = grades.exam_id 
    GROUP BY grades.exam_id, grades.course_id, exam.title  -- Include all selected columns in GROUP BY
) g ON ce.course_id = g.course_id;

";

$res = mysqli_query($connection, $query);

$exams = array();
if($res && mysqli_num_rows($res) != 0){
     while($row = mysqli_fetch_assoc($res)){
        $exam = array(
            "attended_students" => $row['attended_students'],
            "title" => $row['title'],
            "total_students" => $row['total_students'],
        );

        $exams[] = $exam;
     }
     echo json_encode($exams);
    
}else{
    echo "No data Available";
}
