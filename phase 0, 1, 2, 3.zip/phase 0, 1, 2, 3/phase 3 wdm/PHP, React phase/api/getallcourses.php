<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET');

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}



$query = "SELECT c.name as name, u.name as userName, c.course_id as course_id, c.description as description
FROM courses c
INNER JOIN users u ON c.instructor_id = u.user_id;
";
$res = mysqli_query($connection, $query);

if($res){
    $courses = array();
     while($row = mysqli_fetch_assoc($res)){
        $course = array(
            "courseId" => $row['course_id'],
            "courseName" => $row['name'],
            "courseDesc" => $row['description'],
            "name" => $row['userName'],
        );

        $courses[] = $course;
     }
     echo json_encode($courses);
}


?>