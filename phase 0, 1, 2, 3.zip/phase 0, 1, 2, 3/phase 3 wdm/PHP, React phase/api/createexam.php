<?php
header('Access-Control-Allow-Origin: http://localhost:3000'); // Replace with your frontend URL
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');
require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}


$title = $_POST['title'];
$date = $_POST['date'];
$course_id = $_POST['course_id'];
$total = $_POST['total'];


$sql = "INSERT INTO exam (title, date, course_id, total) VALUES ('$title', '$date', '$course_id', '$total')";
$res = mysqli_query($connection, $sql);

if ($res) {
    $exam_id = mysqli_insert_id($connection); // Get the auto-incremented exam_id
    echo $exam_id; // Return the exam_id
} else {
    echo("Creation Failed");
} 


mysqli_close($connection);
?>
