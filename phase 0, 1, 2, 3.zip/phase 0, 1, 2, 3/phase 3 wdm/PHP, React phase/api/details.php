<?php
// Database configuration
define('DB_HOST', 'localhost');
// define('DB_USER', 'sxk2005_root');
// define('DB_PASS', 'Tesla@25');
// define('DB_NAME', 'sxk2005_academiahub');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'keya');
define('MAIL_HOST', 'mail.sxk2005.uta.cloud');
define('MAIL_USER', 'info@sxk2005.uta.cloud');
define('MAIL_PASS', 'Tesla@25');

?>
