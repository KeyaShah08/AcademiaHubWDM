<?php
header('Access-Control-Allow-Origin: http://localhost:3000'); // Replace with your frontend URL
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');
require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}


$exam_id = $_POST['exam_id'];
$question = $_POST['question'];
$option1 = $_POST['option1'];
$option2 = $_POST['option2'];
$option3 = $_POST['option3'];
$option4 = $_POST['option4'];

$sql = "INSERT INTO questions (exam_id, question, option1, option2, option3, option4) VALUES ('$exam_id', '$question', '$option1', '$option2', '$option3', '$option4')";
$res = mysqli_query($connection, $sql);

if ($res) {
    echo true;
} else {
    echo("Creation Failed");
} 


mysqli_close($connection);
?>
