<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');


require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}


$message = mysqli_real_escape_string($connection, $_POST['message']);

$query = "UPDATE contact
SET resolved = 1  -- Set to 1 if resolved, use 0 if unresolved
WHERE message = '$message';";

if (mysqli_query($connection, $query)) {
    // The update was successful
    echo "Contact resolved successfully. Retrieving updated data...";

    
} else {
    echo "Error updating contact: " . mysqli_error($connection);
}
mysqli_close($connection);
?>
