<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST');


require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}


$course_id = mysqli_real_escape_string($connection, $_POST['course_id']);
$query = "SELECT
SUM(total) AS total
FROM
exam
WHERE
course_id = '$course_id';
";

$res = mysqli_query($connection, $query);
$row = mysqli_fetch_assoc($res);
$total = $row['total'];

$query = "SELECT
u.name AS name,
u.email AS email,
SUM(g.score) AS score
FROM
grades AS g
JOIN
users AS u
ON
g.user_id = u.user_id
WHERE
g.course_id = '$course_id'
GROUP BY
g.user_id;



";

$res = mysqli_query($connection, $query);



if($res){
    $grades = array();
     while($row = mysqli_fetch_assoc($res)){
        $grade = array(
            "score" => $row['score'],
            "name" => $row['name'],
            "email" => $row['email'],
            "total" => $total,
        );

        $grades[] = $grade;
     }
     echo json_encode($grades);
}

