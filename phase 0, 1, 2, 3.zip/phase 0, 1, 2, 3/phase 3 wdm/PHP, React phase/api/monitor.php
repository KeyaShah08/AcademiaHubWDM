<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET');

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}



$query = "SELECT * FROM monitor";
$res = mysqli_query($connection, $query);

if($res){
    $logins = array();
     while($row = mysqli_fetch_assoc($res)){
        $login = array(
            "email" => $row['email'],
            "role" => $row['role'],
            "login" => $row['login'],
        );

        $logins[] = $login;
     }
     echo json_encode($logins);
}


?>