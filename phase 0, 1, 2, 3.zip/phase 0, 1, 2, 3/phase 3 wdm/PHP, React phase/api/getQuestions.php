<?php
header('Access-Control-Allow-Origin: http://localhost:3000'); // Replace with your frontend URL
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET');
require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$exam_id = $_GET['exam_id'];

$sql = "SELECT * FROM questions WHERE exam_id = $exam_id";
$result = mysqli_query($connection, $sql);

$questions = array();
while ($row = mysqli_fetch_assoc($result)) {
    $questions[] = $row;
}

echo json_encode($questions);

mysqli_close($connection);
?>
