<?php

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: DELETE');

require('details.php');

$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['eid'])) {
    $eid = mysqli_real_escape_string($connection, $_GET['eid']);

    $deleteQuery = "DELETE FROM course_enrollment WHERE enrollment_id = $eid";
    $res = mysqli_query($connection, $deleteQuery);

    if (mysqli_query($connection, $deleteQuery)) {
        // Deletion was successful
        echo 'Enrollment record deleted successfully';
    } else {
        // Error during deletion
        echo 'Error deleting enrollment record: ' . mysqli_error($connection);
    }
}
?>
