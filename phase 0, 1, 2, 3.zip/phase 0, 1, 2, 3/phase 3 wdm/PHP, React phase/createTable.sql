CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('student', 'instructor', 'qa', 'pc', 'admin') NOT NULL,
  verified BOOLEAN,
  code text NOT NULL,
  UNIQUE KEY (email)
);

-- Set the AUTO_INCREMENT value to start from 1000000
ALTER TABLE users AUTO_INCREMENT = 1000000;


CREATE TABLE courses (
  course_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  instructor_id INT,
  FOREIGN KEY (instructor_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE course_enrollment (
  enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT,
  user_id INT,
  FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE exam (
  exam_id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT,
  date DATE,
  title VARCHAR(255) NOT NULL,
  total INT,
  FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);

CREATE TABLE questions (
  question_id INT AUTO_INCREMENT PRIMARY KEY,
  exam_id INT,
  question TEXT NOT NULL,
  option1 VARCHAR(255) NOT NULL,
  option2 VARCHAR(255) NOT NULL,
  option3 VARCHAR(255) NOT NULL,
  option4 VARCHAR(255) NOT NULL,
  FOREIGN KEY (exam_id) REFERENCES exam(exam_id) ON DELETE CASCADE
);



CREATE TABLE message(
  from_user_id INT,
  to_user_id INT,
  messageDesc TEXT,
  FOREIGN KEY (from_user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (to_user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE monitor (
  email VARCHAR(255) NOT NULL,
  role ENUM('student', 'instructor', 'qa', 'pc', 'admin') NOT NULL,
  login TIMESTAMP NOT NULL
);

CREATE TABLE grades (
  gradeid INT AUTO_INCREMENT PRIMARY KEY,
  exam_id INT,
  user_id INT,
  course_id INT,
  score INT,
  FOREIGN KEY (exam_id) REFERENCES exam(exam_id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);

CREATE TABLE policies (
    policy_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT
);

CREATE TABLE contact (
  contact_id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    name VARCHAR(255) NOT NULL,
    resolved BOOLEAN NOT NULL
);



-- DROP TABLE IF EXISTS contact;
-- DROP TABLE IF EXISTS policies;
-- DROP TABLE IF EXISTS grades;
-- DROP TABLE IF EXISTS monitor;
-- DROP TABLE IF EXISTS message;
-- DROP TABLE IF EXISTS questions;
-- DROP TABLE IF EXISTS exam;
-- DROP TABLE IF EXISTS course_enrollment;
-- DROP TABLE IF EXISTS courses;
-- DROP TABLE IF EXISTS users;
